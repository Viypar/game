package Entity;

import GameState.GameStateManager;
import TileMap.TileMap;

public class Collectable extends MapObject {

	protected int score;
	protected boolean used;
	protected double effect;
	protected int type;
	protected boolean move;
	
	
	
	
	public Collectable(TileMap tm, GameStateManager gsm) {
		super(tm, gsm);
		// TODO Auto-generated constructor stub
	}
	
	// getter
	public boolean isUsed() { return used; }
	
	// setter
	public void isUsed(Boolean b) {
		used = b;
	}
	
	public void setEffect(double d) { this.effect = d; }
	
	public double getEffect() { return effect; }
	
	public int getType() { return type; }
	
	public int getScore() { return score; }
	
	public void playSound() {
		
	}
	
	public void applyEffect() {
		
	}
	
	public void update(GameStateManager gsm) {
		
	}
	

}
