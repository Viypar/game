package Entity;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;

import javax.imageio.ImageIO;

import Audio.AudioPlayer;
import GameState.GameStateManager;
import TileMap.TileMap;

public class Bill extends MapObject {

	// player stuff
			private double health;
			private double maxHealth;
			private double healthRegen;
			private long total_score;
			
			private int gun;
			private int maxGun;
			private int gunRegen;
			private boolean dead;
			private boolean flinching;
			private long flinchTimer;
			private int collectablesFound;
			
			private boolean inventoryVisible;

			private boolean shooting;
			private int shootCost;
			private int shootDamage;
			private ArrayList<Torpedo> photon_torpedos;
		

			private boolean gripping;
			private int gripDamage;
			private int gripRange;

			// gliding
			private boolean gliding;

			// animations
			private ArrayList<BufferedImage[]> sprites;

			// pause
			private boolean quit;
			private GameStateManager gsm;
			private Inventory inv;

			// level complete
			// private boolean levelComplete;

			// these array values come from player sprite file frames. ( 2 for idle, 8 for
			// walking...) tut4 10min
			private final int[] numFrames = { 2, 2, 2, 2 };

			// animation actions
			private static final int UP = 0;
			private static final int DOWN = 1;
			private static final int RIGHT = 2;
			private static final int LEFT = 3;
			private static final int SHOOTING = 4;
			

			// audio
			private HashMap<String, AudioPlayer> sfx;

			// constructor
			public Bill(TileMap tm, GameStateManager gsm) {
				super(tm, gsm);
				
				
				width = 30;
				height = 30;
				cwidth = 20;
				cheight = 20;

				moveSpeed = .1; // .05
				maxSpeed = .8; // 2.3
				stopSpeed = 8;
				verticalSpeed = .1;
				maxVerticalSpeed = .8;
				fallSpeed = 0; // .2
				maxFallSpeed = 0;// 6
				//jumpStart = -5.1; // -4.8 more negative the higher the jump
				//stopJumpSpeed = .3; // .3

				facingRight = true;

				health = maxHealth = 100;
				healthRegen = .001; // .001default
				gun = maxGun = 1000;
				gunRegen = 10; // default

				shootCost = 100;
				shootDamage = 25;
				photon_torpedos = new ArrayList<Torpedo>();

				gripDamage = 3;
				gripRange = 30;

				// load sprites
				try {

					BufferedImage spritesheet = ImageIO.read(getClass().getResourceAsStream("/Sprites/Player/open_world_player.gif"));

					sprites = new ArrayList<BufferedImage[]>();

					for (int i = 0; i < 4; i++) {
						BufferedImage[] bi = new BufferedImage[numFrames[i]];
						for (int j = 0; j < numFrames[i]; j++) {
							
								bi[j] = spritesheet.getSubimage(j * width, i * height, width, height);
							 
						}

						sprites.add(bi);

					}

				} catch (Exception e) {
					e.printStackTrace();
				}

				animation = new Animation();
				currentAction = UP;
				animation.setFrames(sprites.get(UP));
				animation.setDelay(200);

				sfx = new HashMap<String, AudioPlayer>();
				//sfx.put("jump", new AudioPlayer("/SFX/playerjump.mp3"));
				//sfx.put("grip", new AudioPlayer("/SFX/playegrip.mp3"));
				sfx.put("phaser", new AudioPlayer("/SFX/phasersound_2.mp3"));
				sfx.put("lowhealth", new AudioPlayer("/SFX/lowhealth.mp3"));

			}

			public double getHealth() {
				return health;
			}

			public double getMaxHealth() {
				return maxHealth;
			}

			public int getGun() {
				return gun;
			}

			public int getMaxGun() {
				return maxGun;
			}

			public int getCollectablesFound() {
				return collectablesFound;
			}

			public void foundCollectable() {
				collectablesFound++;
			}

			public void setMaxFallSpeed(double d) {
				this.maxFallSpeed = d;
			}

			public void setJumpStart(double d) {
				this.jumpStart = d;
			}

			public void setShooting(Boolean b) {
				// this.shooting = b;
				shooting = b;
			}

		
		
			public void checkAttack(ArrayList<Enemy> enemies, ArrayList<PowerUp> powerUps,
					ArrayList<Collectable> collectables) {

				// for all enemies
				for (int i = 0; i < enemies.size(); i++) {

					Enemy e = enemies.get(i);

//					// check grip attack
//					if (gripping) {
//						if (facingRight) {
//							if (e.getx() > x && e.getx() < x + gripRange && e.gety() > y - height 
//									&& e.gety() < y + height ) {
//								e.hit(gsm, gripDamage);
//							}
//						} else {
//							if (e.getx() < x && e.getx() > x - gripRange && e.gety() > y - height 
//									&& e.gety() < y + height ) {
//								e.hit(gsm, gripDamage);
//							}
//						}
//					}

					// check phaserBeams attack
					for (int j = 0; j < photon_torpedos.size(); j++) {
						if (photon_torpedos.get(j).intersects(e)) {
							// e.playSound();
							e.hit(gsm, shootDamage);
							photon_torpedos.get(j).setHit();
							break;
						}
					}

					// check enemy collision
					if (intersects(e)) {
						playerHit(e, e.getDamage());
						e.setEnemyAttacking(true);// this doesn't seem to make a difference

					}

				} // end all enemies loop

				// check power ups collision
				for (int i = 0; i < powerUps.size(); i++) {

					PowerUp p = powerUps.get(i);

					// check powerUp collision
					if (intersects(p)) {

						add(p, p.getMultiplier());
					}
				}

				// check collectables collision
				for (int i = 0; i < collectables.size(); i++) {
					Collectable c = collectables.get(i);
					if (intersects(c)) {
						collectablesFound += 1;

						addCollectable(c, c.getEffect());
						// foundCollectable();
					}
				}

			}// end checkAttack()

			// this is the enemy that has collided doing damage to the player
			public void playerHit(Enemy e, int damage) {////////////////////////////////////
				if (flinching)
					return;
				e.playSound();
				e.setEnemyAttacking(true);///////////////

				// e.setAttack(true);
				// sfx.get(e.getSound()).play();
				health -= damage;
				if (health < 0) {
					health = 0;
					dead = true;
				}

				if (health <= 20) {
					sfx.get("lowhealth").play();
				}

				flinching = true;
				flinchTimer = System.nanoTime();

			}

			public void add(PowerUp p, double multiplier) {
				// ph.playSound();
				if (p.isUsed() == false) {
					// p.playSound();
					if (p.getType() == 0) {
						this.maxHealth = maxHealth * multiplier;
						this.health = maxHealth;
						this.healthRegen = .1;
						//gsm.addToScore(50);
						p.isUsed(true);
					}

					if (p.getType() == 1) {
						this.maxGun = (int) (maxGun * multiplier);
						this.gun = maxGun;
						this.gunRegen = 3;
						//gsm.addToScore(50);
						p.isUsed(true);
					}

//					if (p.getType() == 2) {
//						this.maxSpeed *= p.getMultiplier();
//						p.isUsed(true);
//					}

				}

			}

			public void addCollectable(Collectable c, double effect) {
				if (c.isUsed() == false) {
					if (c.getType() == 0) {
						// todo ... add effect

						this.health += 10; // coin health benefit
						//gsm.addToScore(20);
						c.isUsed(true);
					}
				}
			}

			////////
			public void setDead() {
				this.dead = true;
			}

			public boolean checkDead() {
				return dead;
			}

			public void setQuit(Boolean b) {
				this.quit = b;
			}

			public boolean getQuit() {
				return quit;
			}
			
			public void setInventoryVisible() {
				if(inventoryVisible) {
					inventoryVisible = false;
				}
				else {
					inventoryVisible = true;
				}
			}
			public Boolean getInventoryVisible() { return inventoryVisible; }
			

			public void getNextPosition() { // private
//				

				// movement
				if (left) {
					dy = 0;	//so player doesn't move diagonally
					dx -= moveSpeed;
					if (dx < -maxSpeed ) {
						//dx = 0;
					}
					if (dx < -maxSpeed) {
						dx = -maxSpeed;
					}
				} else if (right) {
					dy = 0;
					dx += moveSpeed;
					if (dx < maxSpeed ) {
						//dx = 0;
					}
					if (dx > maxSpeed) {
						dx = maxSpeed;
					}
				} else if (up) {
					dx = 0;
					dy -= verticalSpeed;
					if(dy < -maxVerticalSpeed) {
						//dy = 0;
					}
					if (dy < -maxVerticalSpeed) {
						dy = -maxVerticalSpeed; 
					}
				} else if (down) {
					dx = 0;
					dy += verticalSpeed;
					if(dy < maxVerticalSpeed) {
						//dy = 0;
					}
					if (dy > maxVerticalSpeed) {
						dy = maxVerticalSpeed;
					}
				} 
//					else if(down) {
//					dy += moveSpeed;
//					if (dy > maxSpeed) {
//						dy = maxSpeed;
//					}
//				} else if(up) {
//					dy -= moveSpeed;
//					if (dy < -maxSpeed) {
//						dy = -maxSpeed;
//					}
//				} else {
////					if (dx > 0) {
////						dx -= stopSpeed;
////						if (dx < 0) {
////							dx = 0;
////						}
////					} else if (dx < 0) {
////						dx += stopSpeed;
////						if (dx > 0) {
////							dx = 0;
////						}
////					}
//					
//				}

//				// cannot move while attacking, except in air
//				if ((currentAction == GRIPPING || currentAction == SHOOTING) && !(jumping || falling)) {
//					dx = 0;
//				}

//				// jumping
//				if (jumping && !falling) {
//					sfx.get("jump").play();
//					// sfx.get("jump").stop();
//					dy = jumpStart;
//					falling = true;
//				}

//				// falling
//				if (falling) {
	//
//					if (dy > 0 && gliding) {
//						dy += fallSpeed * 0.1; // falling while gliding is at 10% speed of normal fall
//					} else {
//						dy += fallSpeed;
//					}
//					if (dy > 0) {
//						jumping = false;
//					}
//					if (dy < 0 && !jumping) { // longer you hold jump, the higher you'll jump
//						dy += stopJumpSpeed;
//					}
//					if (dy > maxFallSpeed) {
//						dy = maxFallSpeed;
//					}
	//
//				}

			}// end getNextPosition()

			public void update() {

				// update position
				getNextPosition();

				checkTileMapCollision();
				setPosition(xtemp, ytemp);

				// check attack has stopped
//				if (currentAction == GRIPPING) {
//					if (animation.hasPlayedOnce())
//						gripping = false;
//					if (gripping && currentAction != GRIPPING) {
//						sfx.get("grip").play();
//					}
	//
//				}
				if (currentAction == SHOOTING) {
					if (animation.hasPlayedOnce())
						shooting = false;
					// sfx.get("phaser").stop();
				}

				// health Regen
				health += healthRegen;
				if (health > maxHealth) {
					health = maxHealth;
				}

				// shooting attack
				gun += gunRegen;
				if (gun > maxGun)
					gun = maxGun;
				// if(gun < maxGun) gun += 10;
				
					if (shooting && currentAction != SHOOTING) {
						if (gun > shootCost) {
							sfx.get("phaser").play();
							gun -= shootCost;
							Torpedo t1 = new Torpedo(tileMap, facingRight,facingUp, gsm);
//							Torpedo t2 = new Torpedo(tileMap, facingRight,facingUp, gsm);
//							Torpedo t3 = new Torpedo(tileMap, facingRight,facingUp, gsm);
							t1.setPosition(x, y);
//							t2.setPosition(x - 10, y);
//							t3.setPosition(x + 10, y);
							photon_torpedos.add(t1);
//							photon_torpedos.add(t2);
//							photon_torpedos.add(t3);
//							Phaser ph = new Phaser(tileMap, facingRight, gsm); // 0 for player phaser, 1 for enemy
//							ph.setPosition(x, y);
//							phaserBeams.add(ph);
						}
					}
				
				
				// update photon_torpedos
				for (int i = 0; i < photon_torpedos.size(); i++) {
					photon_torpedos.get(i).update();
					if (photon_torpedos.get(i).shouldRemove()) {
						photon_torpedos.remove(i);
						i--;
					}
				}

				// check done flinching
				if (flinching) {
					long elapsed = (System.nanoTime() - flinchTimer) / 1000000;
					if (elapsed > 1000) {
						flinching = false;
					}
				}

				// set animation
//				if (gripping) {
//					if (currentAction != GRIPPING) {
//						sfx.get("grip").play();
//						// sfx.get("grip").stop();
//						currentAction = GRIPPING;
//						animation.setFrames(sprites.get(GRIPPING));
//						animation.setDelay(50);
//						width = 60;
//					}
//				} 
				if (shooting) {
					if (currentAction != SHOOTING) {
						currentAction = SHOOTING;
//						animation.setFrames(sprites.get(SHOOTING));
//						animation.setDelay(100);
//						width = 30;
					}
				} 
//					else if (dy > 0) {
//					if (gliding) {
//						if (currentAction != GLIDING) {
//							currentAction = GLIDING;
//							animation.setFrames(sprites.get(GLIDING));
//							animation.setDelay(100);
//							width = 30;
//						}
//					} else if (currentAction != FALLING) {
//						currentAction = FALLING;
//						animation.setFrames(sprites.get(FALLING));
//						animation.setDelay(100);
//						width = 30;
//					}
//				} else if (dy < 0) {
//					if (currentAction != JUMPING) {
//						currentAction = JUMPING;
//						animation.setFrames(sprites.get(JUMPING));
//						animation.setDelay(-1);
//						width = 30;
//					}
//				} 
				else if (left || right) {
					if (currentAction != RIGHT) {
						currentAction = RIGHT;
						animation.setFrames(sprites.get(RIGHT));
						animation.setDelay(200);
						width = 30;
					}
				}
				else if (up) {
					if (currentAction != UP) {
						currentAction = UP;
						animation.setFrames(sprites.get(UP));
						animation.setDelay(200);
						width = 30;
					}
				} else if (down) {
					if(currentAction != DOWN) {
						currentAction = DOWN;
						animation.setFrames(sprites.get(DOWN));
						animation.setDelay(200);
						width = 30;
					}
				}
				

				animation.update();

				// set direction
				
					if (right)
						facingRight = true;
					if (left)
						facingRight = false;
					if (up)
						facingUp = true;
					if (down)
						facingUp = false;
				

			}

			public void draw(Graphics2D g) {

				setMapPosition();

				// draw phaserBeams
				for (int i = 0; i < photon_torpedos.size(); i++) {
					photon_torpedos.get(i).draw(g);
				}

				// draw player
				if (flinching) {
					long elapsed = (System.nanoTime() - flinchTimer) / 1000000;
					if (elapsed / 100 % 2 == 0) {
						return;
					}
				}

				super.draw(g);

			}
	
}
