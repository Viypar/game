package Entity.Enemies;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import javax.imageio.ImageIO;

import Audio.AudioPlayer;
import Entity.Animation;
import Entity.Enemy;
import GameState.GameStateManager;
import TileMap.TileMap;

public class Pancake extends Enemy {

	// private BufferedImage[] sprites;
	// audio
	private HashMap<String, AudioPlayer> sfx;

	// animations
//	private BufferedImage[] sprites;
	private ArrayList<BufferedImage[]> sprites;

	//private boolean attacking;
	
	// private boolean isDead;

	// animation actions
	private static final int FLYING = 0;
	//private static final int ATTACKING = 1;
	
	//private int attackRange = 200;
	// private int shootDamage = 5;
	// private int gun = 5000;
	// private int maxGun = 5000;
	// private int shootCost = 100;
	//private ArrayList<Phaser> phaserBeams;
	
	final int[] numFrames = { 3 };
	
	
	Random rand = new Random();

	// constructor
	public Pancake(TileMap tm, GameStateManager gsm) {
		super(tm, gsm);
		this.score = 50;

		// type = 0; //0 = moving type, 1 = stationary type
		moveSpeed = 1.25; // 2
		maxSpeed = 1.5; // 2.5
		fallSpeed = 0;
		maxFallSpeed = 0;

		width = 30; // tilesheet?
		height = 30;
		cwidth = 20; // real w and h ?
		cheight = 20;

		health = maxHealth = 3;
		damage = 2;

		sfx = new HashMap<String, AudioPlayer>();
		 sfx.put("pancakevoice", new AudioPlayer("/SFX/pancakevoice.mp3"));

		// load sprites

		try {

			BufferedImage spritesheet = ImageIO.read(getClass().getResourceAsStream("/Sprites/Enemies/pancake.gif"));
			sprites = new ArrayList<BufferedImage[]>();
			for (int i = 0; i < 1; i++) {
				BufferedImage[] bi = new BufferedImage[numFrames[i]];
				for(int j = 0; j < numFrames[i]; j++) {
					bi[j] = spritesheet.getSubimage(j * width, i * height, width, height);
				}
				sprites.add(bi);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		animation = new Animation();
		currentAction = FLYING;
		animation.setFrames(sprites.get(FLYING));
		animation.setDelay(300);

		up = true;
		right = true;
		facingRight = true;

	}



	public void setType(int i) {
		type = i; // 0 = horizontal, 1 = vertical
	}

	public void setSpeed(double s) {
		moveSpeed = s;
	}
	
	public void playSound() {
		 sfx.get("pancakevoice").play();
	}

		public String getEnemySound() {
			return "pancakevoice";
		}
		
		
		

	private void getNextPosition() {

		if (type == 0) {
			// movement
			if (left) {
				dx += moveSpeed; // had to invert these so snake would look right (+= and -= and <>)
				if (dx > maxSpeed) {
					dx = maxSpeed;
				}
			} else if (right) {
				dx -= moveSpeed;
				if (dx < -maxSpeed) {
					dx = -maxSpeed;
				}
			}

		
		}else if(type == 1) {
			if(down) {
				dy += moveSpeed;
				if(dy > maxSpeed) {
					dy = maxSpeed;
				}
			}else if (up) {
				dy -= moveSpeed;
				if(dy < -maxSpeed) {
					dy = -maxSpeed;
				}
			}
			
			
		}
				
	

	}

	public void update(GameStateManager gsm) {

		// update position
		getNextPosition();
		checkTileMapCollision();
		setPosition(xtemp, ytemp);

		// check flinching
		if (flinching) {
			long elapsed = (System.nanoTime() - flinchTimer) / 1000000;
			if (elapsed > 400) {
				flinching = false;
			}
		}

		if (type == 0) {
			// if it hits a wall, go other direction
			if (right && dx == 0) {
				right = false;
				left = true;
				facingRight = false;
			} else if (left && dx == 0) {
				right = true;
				left = false;
				facingRight = true;
			}
		}
		
		if(type == 1) {
			if(up && dy == 0) {
				up = false;
				down = true;
				facingRight = false;
			}else if( down && dy == 0) {
				up = true;
				down = false;
				facingRight = true;
			}
		}
		if(currentAction != FLYING) {
			
		}

		// update animation
		animation.update();

	}

	public void draw(Graphics2D g) {

		// if(notOnScreen())return;
		setMapPosition();
		super.draw(g);
	}

}
