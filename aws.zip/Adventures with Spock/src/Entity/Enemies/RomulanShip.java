package Entity.Enemies;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import javax.imageio.ImageIO;

import Audio.AudioPlayer;
import Entity.Animation;
import Entity.Boulder;
import Entity.Enemy;
import Entity.Phaser;
import Entity.Player;
import GameState.GameStateManager;
import TileMap.TileMap;

public class RomulanShip extends Enemy {

	// private BufferedImage[] sprites;
		// audio
		private HashMap<String, AudioPlayer> sfx;
		// animations
		private ArrayList<BufferedImage[]> sprites;

		//private boolean attacking;
		private boolean turn;
		
		// private boolean isDead;

		// animation actions
		private static final int DOWN = 0;
		private static final int UP= 1;
		private static final int RIGHT = 2;
		private static final int LEFT = 3;
		private static final int SHOOTING = 4;
		
		private int turnCount = 0;
		
		private int attackRange = 40;
		private int shootDamage = 4;
		// private int gun = 5000;
		// private int maxGun = 5000;
		private int shootCost = 150;
		private ArrayList<Phaser> phaserBeams;
		//private ArrayList<Boulder> boulder;
		private Player player;
		Random rand = new Random();

		// constructor
		public RomulanShip(TileMap tm, GameStateManager gsm, Player p) {
			super(tm, gsm);
			this.player = p;
			this.score = 100;
			//System.out.println(this.score);

			moveSpeed = .2; // 1.6
			maxSpeed = .2; // 2
			fallSpeed = 0.2;
			maxFallSpeed = 0.2;


			
			
			width = 30;
			height = 30;
			cwidth = 20; // real w and h ?
			cheight = 20;

			health = maxHealth = 30;
			// healthRegen = .1; //default for all
			gun = maxGun = 5000;
			
			damage = 2;
			//boolean attacking;

			// these array values come from player sprite file frames. ( 2 for idle, 8 for
			// walking...) tut4 10min
			final int[] numFrames = { 1, 1, 1, 1 };

			sfx = new HashMap<String, AudioPlayer>();
			sfx.put("gorn_voice", new AudioPlayer("/SFX/gorn_voice.mp3"));
			//sfx.put("gorn_death", new AudioPlayer("SFX/gorn_death.mp3"));
			

			//phaserBeams = new ArrayList<Phaser>();
			//boulder = new ArrayList<Boulder>();

			// load sprites

			try {

				BufferedImage spritesheet = ImageIO.read(getClass().getResourceAsStream("/Sprites/Enemies/romulan_ship.gif"));
				sprites = new ArrayList<BufferedImage[]>();
				for (int i = 0; i < 5; i++) {
					BufferedImage[] bi = new BufferedImage[numFrames[i]];
					for (int j = 0; j < numFrames[i]; j++) {

						bi[j] = spritesheet.getSubimage(j * width, i * height, width, height);

					}

					sprites.add(bi);

				}

			} catch (Exception e) {
				e.printStackTrace();
			}

			animation = new Animation();
			currentAction = DOWN;
			animation.setFrames(sprites.get(DOWN));
			animation.setDelay(300);

//					sfx = new HashMap<String, AudioPlayer>();
//					sfx.put("jump", new AudioPlayer("/SFX/playerjump.mp3"));
//					sfx.put("grip", new AudioPlayer("/SFX/playegrip.mp3"));
//					sfx.put("phaser", new AudioPlayer("/SFX/playershoot.mp3"));

			down = true;
			//right = true;
			//facingRight = true;

//					int getHealth() { return health; }
//					public int getMaxHealth() { return maxHealth; }

		}

		public void playSound() {
			sfx.get("gorn_voice").play();
		}

//		public String getEnemySound() {
//			return "gorn_voice";
//		}
//		public String getEnemyDeathSound() {
//			return "gorn_death";
//		}
		public void playDeathSound() {
			sfx.get("gorn_death").play();
		}

//		public void setTurn() {// not needed
//			turn = true;
//		}

		public int distanceToTurn() {
			return (int) Math.floor(Math.random() * 5000); // this affects gorn left and right frequency
		}

	
		
		// checking grip attack
		public void checkAttack(Player p) {


			// check grip attack
			if (attacking) {
				if (facingRight) {
					if (p.getx() > x && p.getx() < x + attackRange && p.gety() > y - height / 4
							&& p.gety() < y + height / 4) {
						p.playerHit(this, damage);
					}
				}
				
			} else {
					if (p.getx() < x && p.getx() > x - attackRange && p.gety() > y - height / 4
							&& p.gety() < y + height / 4) {
						p.playerHit(this, damage);
					}
				}
	}
		
		
		private void getNextPosition() {

//			// movement
//			if (left) {
//				dx -= moveSpeed;
//				if (dx < -maxSpeed) {
//					dx = -maxSpeed;
//				}
//			} else if (right) {
//				dx += moveSpeed;
//				if (dx > maxSpeed) {
//					dx = maxSpeed;
//				}
//			} else if (up) {
//				dy -= verticalSpeed;
//				if (dy < -maxVerticalSpeed) {
//					dy = -maxVerticalSpeed; 
//				}
//			} else if (down) {
//				dy += verticalSpeed;
//				if (dy > maxVerticalSpeed) {
//					dy = maxVerticalSpeed;
//				}
//			} 

			

		}

		public void update(GameStateManager gsm) {
			turnCount++;
			
			

			
			// health regen
			health += healthRegen;
			if (health > maxHealth) {
				health = maxHealth;
			}

			gun += 2; // gun increment can't be inside the phaser beam creation loop, because it only
						// happens on turn
			
			checkAttack(player);
			
			// update position
			getNextPosition();
			checkTileMapCollision();
			setPosition(xtemp, ytemp);

			// check attack has stopped
					if (currentAction == SHOOTING) {
						if (animation.hasPlayedOnce())
							setEnemyAttacking(false);
							attacking = false;
						if (attacking && currentAction != SHOOTING) {
							//sfx.get("grip").play();
						}
						// currentAction = WALKING;
						// attacking = false;
					}

					// check flinching
					if (flinching) {
						long elapsed = (System.nanoTime() - flinchTimer) / 1000000;
						if (elapsed > 800) {
							flinching = false;
						}
					}

					// attempting turn
					if (distanceToTurn() <= turnCount) {
						turnCount = 0;
						
						currentAction = SHOOTING;
						if (gun > maxGun)
							gun = maxGun;
						if (gun > shootCost) {
							// sfx.get("phaser").play(); //change this to gorn phaser sound, also declare
							// above...
							gun -= shootCost;
							Phaser ph = new Phaser(tileMap, facingRight, gsm);
							ph.setPosition(x, y);
							phaserBeams.add(ph);
							

						}
						
						
						
						// if it hits a wall, go other direction
						if (right) {
							right = false;
							left = true;
							facingRight = false;
							
						} else if (left) {
							right = true;
							left = false;
							facingRight = true;
						}
						if(up) {
							up = false;
							down = true;
							facingUp = false;
						}
						else if(down) {
							up = true;
							down = false;
							facingUp = true;
						}
					}
					
				

					// set animation
					if (attacking) {
						if (currentAction != SHOOTING) {
							currentAction = SHOOTING;
							animation.setFrames(sprites.get(SHOOTING));
							animation.setDelay(100);
							width = 30;
						}
					
					} else if (left || right) {
						if (currentAction != RIGHT) {
							currentAction = RIGHT;
							animation.setFrames(sprites.get(RIGHT));
							animation.setDelay(-1);
							width = 30;
						}
					} else if(up) {
						if (currentAction != UP) {
							currentAction = UP;
							animation.setFrames(sprites.get(UP));
							animation.setDelay(-1);
							width = 30;
						}
					}else if (down) {
						if(currentAction != DOWN) {
							currentAction = DOWN;
							animation.setFrames(sprites.get(DOWN));
							animation.setDelay(-1);
							width = 30;
						}
					}
					else {
						if(currentAction != DOWN) {
							currentAction = DOWN;
							animation.setFrames(sprites.get(DOWN));
							animation.setDelay(-1);
							width = 30;
						}
					} 
						
						
						
				

					// shooting attack

//						if( gun > maxGun) gun = maxGun;
//						if(gun > shootCost) {
//							//sfx.get("phaser").play();	//change this to gorn phaser sound, also declare above...
//							gun -= shootCost;
//							Phaser ph = new Phaser(tileMap, facingRight, gsm);
//							ph.setPosition(x, y);
//							phaserBeams.add(ph);
			//
//						}

//						if (right) {
//							facingRight = false;
//							right = false;
//							left = true;
//							facingRight = false;
//						} else if (left) {
//							right = true;
//							left = false;
//							facingRight = true;
//						}

	//PHASERBEAMS
					// check phaserBeams attack
								for(int j = 0; j < phaserBeams.size(); j++) {
									if(phaserBeams.get(j).intersects(player)) {
										player.playerHit(this, shootDamage);
										phaserBeams.get(j).setHit();
										break;
									}
								}	

	
					
					
					// check enemy collision
					if (intersects(player)) {
						player.playerHit(this, damage);

					}

					

					
//	 UPDATING PHASERBEAMS				
					// update phaserBeams
					for(int i = 0; i < phaserBeams.size(); i++) {
						phaserBeams.get(i).update();
						if(phaserBeams.get(i).shouldRemove()) {
							phaserBeams.remove(i);
							i--;
						}
					}

			//
//					// attempting turn
//					if (distanceToTurn() <= turnCount) {
//						turnCount = 0;
//					}

					// updating animation here...
					animation.update();

		}

		public void draw(Graphics2D g) {

			// if(notOnScreen())return;
			setMapPosition();


			
//			// draw phaserBeams
			for (int i = 0; i < phaserBeams.size(); i++) {
				phaserBeams.get(i).draw(g);
			}
			if (flinching) {
				long elapsed = (System.nanoTime() - flinchTimer) / 1000000;
				if (elapsed / 100 % 2 == 0) {
					return;
				}
			}

			super.draw(g);
		}
	
	
}
