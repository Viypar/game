package Entity.Enemies;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import javax.imageio.ImageIO;

import Audio.AudioPlayer;
import Entity.Animation;
import Entity.Enemy;
import Entity.Phaser;
import Entity.Player;
import GameState.GameStateManager;
import TileMap.TileMap;

public class Vampire extends Enemy {

	// private BufferedImage[] sprites;
	// audio
	private HashMap<String, AudioPlayer> sfx;
	// animations
	private ArrayList<BufferedImage[]> sprites;

	// private boolean attacking;
	//private boolean turn;
	private boolean jump;
	// private boolean isDead;

	// animation actions
	private static final int IDLE = 0;
	private static final int WALKING = 1;
	private static final int JUMPING = 2;
	private static final int FALLING = 3;
	private static final int FIGHTING = 4;

	private int turnCount = 0;
	private int jumpCount = 0;

	private int attackRange = 60;
	private int shootDamage = 5;
	private int damage = 3;
	 private int gun = 1000;
	 private int maxGun = 1000;
	private int shootCost = 100;
	private ArrayList<Phaser> phaserBeams;
//	private ArrayList<Boulder> boulder;
	private Player player;
	Random rand = new Random();

	public Vampire(TileMap tm, GameStateManager gsm, Player p) {
		super(tm, gsm);
		this.player = p;
		this.score = 150;

		moveSpeed = 1.2; // 1.2
		maxSpeed = 1.8; // 2
		fallSpeed = .2;
		maxFallSpeed = 10;	//10

		jumpStart = -3.5; // -4
		stopJumpSpeed = .2; // .3

		facingRight = true;
		
		
		// this.tileSize = 60;
		width = 60;
		height = 60;
		cwidth = 50; // real w and h ? collision width??
		cheight = 50;

		health = maxHealth = 50;
		// healthRegen = .1; //default for all
		// gun = maxGun = 5000;
		damage = 3;
		// boolean attacking;

		// these array values come from player sprite file frames. ( 2 for idle, 8 for
		// walking...) tut4 10min
		final int[] numFrames = { 1, 3, 1, 2, 3 };

		sfx = new HashMap<String, AudioPlayer>();
		sfx.put("vampirevoice", new AudioPlayer("/SFX/vampirevoice.mp3"));

		 phaserBeams = new ArrayList<Phaser>();
		//boulder = new ArrayList<Boulder>();

		// load sprites

		try {

			BufferedImage spritesheet = ImageIO.read(getClass().getResourceAsStream("/Sprites/Enemies/vampire.gif"));

			sprites = new ArrayList<BufferedImage[]>();

			for (int i = 0; i < 5; i++) {
				BufferedImage[] bi = new BufferedImage[numFrames[i]];
				for (int j = 0; j < numFrames[i]; j++) {

					bi[j] = spritesheet.getSubimage(j * width, i * height, width, height);

				}

				sprites.add(bi);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		animation = new Animation();
		currentAction = WALKING;
		animation.setFrames(sprites.get(WALKING));
		animation.setDelay(300);

//				sfx = new HashMap<String, AudioPlayer>();
//				sfx.put("jump", new AudioPlayer("/SFX/playerjump.mp3"));
//				sfx.put("grip", new AudioPlayer("/SFX/playegrip.mp3"));
//				sfx.put("phaser", new AudioPlayer("/SFX/playershoot.mp3"));

		right = true;
		facingRight = true;

//				int getHealth() { return health; }
//				public int getMaxHealth() { return maxHealth; }

	}

	public void playSound() {
		 sfx.get("vampirevoice").play();
	}

	public String getEnemySound() {
		return "vampirevoice";
	}

//	public void setTurn() {// not needed
//		turn = true;
//	}
	public void setJump() {
		jump = true;
	}

	public int distanceToTurn() {
		return (int) Math.floor(Math.random() * 800); // this affects gorn left and right frequency
	}
	public int timeToJump() {
		return(int) Math.floor(Math.random() * 20000 );
	}

	public void checkAttack(Player p) {


			// check grip attack
			if (attacking) {
				if (facingRight) {
					if (p.getx() > x && p.getx() < x + attackRange && p.gety() > y - height / 4
							&& p.gety() < y + height / 4) {
						p.playerHit(this, damage);
					}
				}
				
			} else {
					if (p.getx() < x && p.getx() > x - attackRange && p.gety() > y - height / 4
							&& p.gety() < y + height / 4) {
						p.playerHit(this, damage);
					}
				}
	}
			

//			// check phaserBeams attack
//			for (int j = 0; j < phaserBeams.size(); j++) {
//				if (phaserBeams.get(j).intersects(p)) {
//					p.playerHit(this, shootDamage);
//					phaserBeams.get(j).setHit();
//					break;
//				}
//			}
//
//			// check enemy collision
//			if (intersects(p)) {
//				p.playerHit(this, damage);
//				setEnemyAttacking(true);
//				// e.setEnemyAttacking(true);// this doesn't seem to make a difference
//
//			}


//
//	}// end checkAttack()

	private void getNextPosition() {
		// movement
		if (left) {
			dx -= moveSpeed;
			if (dx < -maxSpeed) {
				dx = -maxSpeed;
			}
		} else if (right) {
			dx += moveSpeed;
			if (dx > maxSpeed) {
				dx = maxSpeed;
			}
		} else {
			if (dx > 0) {
				dx -= stopSpeed;
				if (dx < 0) {
					dx = 0;
				}
			} else if (dx < 0) {
				dx += stopSpeed;
				if (dx > 0) {
					dx = 0;
				}
			}
		}

		// cannot move while attacking, except in air
		if ((currentAction == FIGHTING) && !(jumping || falling)) {
			dx = 0;
		}

		if(jump) {
			jump = false;
			dy = jumpStart;
			falling = true;
			
		}
//		// jumping
//		if (jump && !falling) {
//			sfx.get("jump").play();
//			// sfx.get("jump").stop();
//			
//			falling = true;
//		}

		// falling
		if (falling) {

			if (dy > 0) {
				dy += fallSpeed * 0.1; // falling while gliding is at 10% speed of normal fall
			} else {
				dy += fallSpeed;
			}
			if (dy > 0) {
				jumping = false;
			}
			if (dy < 0 && !jumping) { // longer you hold jump, the higher you'll jump
				dy += stopJumpSpeed;
			}
			if (dy > maxFallSpeed) {
				dy = maxFallSpeed;
			}

		}

		// update animation?

	}

	public void update(GameStateManager gsm) {
		turnCount++;
		jumpCount++;

		gun += 2; // gun increment can't be inside the phaser beam creation loop, because it only
					// happens on turn
		// health regen
		health += healthRegen;
		if (health > maxHealth) {
			health = maxHealth;
		}

		// update position
		checkAttack(player);
		getNextPosition();
		checkTileMapCollision();
		setPosition(xtemp, ytemp);

		// check attack has stopped
		if (currentAction == FIGHTING) {
			if (animation.hasPlayedOnce())
				setEnemyAttacking(false);
				attacking = false;
			if (attacking && currentAction != FIGHTING) {
				sfx.get("grip").play();
			}
			// currentAction = WALKING;
			// attacking = false;
		}

		// check flinching
		if (flinching) {
			long elapsed = (System.nanoTime() - flinchTimer) / 1000000;
			if (elapsed > 1000) {
				flinching = false;
			}
		}

		// attempting turn
		if (distanceToTurn() <= turnCount) {
			turnCount = 0;
			

			if (gun > maxGun)
				gun = maxGun;
			if (gun > shootCost) {
				// sfx.get("phaser").play(); //change this to gorn phaser sound, also declare
				// above...
				gun -= shootCost;
				Phaser ph = new Phaser(tileMap, facingRight, gsm);	// 0 for player, 1 for enemy
				ph.setPosition(x, y + 10);
				phaserBeams.add(ph);
//				Boulder b = new Boulder(tileMap, facingRight, gsm);
//				b.setPosition(x, y  );	//add to x and y to make boulders come out differently
//				boulder.add(b);

			}
			
			
			
			// if it hits a wall, go other direction
			if (right) {
				right = false;
				left = true;
				facingRight = false;
				
			} else if (left) {
				right = true;
				left = false;
				facingRight = true;
			}
		}
		
		//atempting jump
		if( timeToJump() <= jumpCount) {
			jumpCount = 0;
			jump = true;
			setJumping(true);
			//falling = true;

			//currentAction = JUMPING;
		}

		// set animation
		if (attacking) {
			if (currentAction != FIGHTING) {
				// play sound
				currentAction = FIGHTING;
				animation.setFrames(sprites.get(FIGHTING));
				animation.setDelay(400);
				width = 60;
			}

		} else if (dy > 0) {
			if (currentAction != FALLING) {
				currentAction = FALLING;
				//jump = false;
				animation.setFrames(sprites.get(FALLING));
				animation.setDelay(300);
				width = 60;
			}
//			currentAction = WALKING;
//			animation.setFrames(sprites.get(WALKING));
//			animation.setDelay(300);
		} else if ( dy < 0) {
			if(!jump && currentAction != JUMPING) {
				jump = true;
				currentAction = JUMPING;
				animation.setFrames(sprites.get(JUMPING));
				animation.setDelay(300);
				width = 60;
				falling = true;
			
			}
		} else if (left || right) {
			if (currentAction != WALKING) {
				currentAction = WALKING;
				animation.setFrames(sprites.get(WALKING));
				animation.setDelay(300);
				width = 60;
			}
		} else {
			if(currentAction != IDLE) {
				currentAction = IDLE;
				animation.setFrames(sprites.get(IDLE));
				animation.setDelay(400);
				width = 60;
			}
		} 
			
			
			
	

		// shooting attack

//			if( gun > maxGun) gun = maxGun;
//			if(gun > shootCost) {
//				//sfx.get("phaser").play();	//change this to gorn phaser sound, also declare above...
//				gun -= shootCost;
//				Phaser ph = new Phaser(tileMap, facingRight, gsm);
//				ph.setPosition(x, y);
//				phaserBeams.add(ph);
//
//			}

//			if (right) {
//				facingRight = false;
//				right = false;
//				left = true;
//				facingRight = false;
//			} else if (left) {
//				right = true;
//				left = false;
//				facingRight = true;
//			}

		// check phaserBeams attack
					for(int j = 0; j < phaserBeams.size(); j++) {
						if(phaserBeams.get(j).intersects(player)) {
							player.playerHit(this, shootDamage);
							phaserBeams.get(j).setHit();
							break;
						}
					}	

//		// check boulder attack
//		for(int i = 0; i < boulder.size(); i++) {
//			if(boulder.get(i).intersects(player)) {
//				player.playerHit(this, shootDamage);
//				boulder.get(i).setHit();
//				break;
//			}
//		}
		
		
//		// check enemy collision
//		if (intersects(player)) {
//			player.playerHit(this, damage);
//
//		}
		
		//update boulders
//		// update  boulder throw
//		for(int i = 0; i < boulder.size(); i++) {
//			boulder.get(i).update();
//			if(boulder.get(i).shouldRemove()) {
//				boulder.remove(i);
//				i--;
//			}
//		}
		

//		
//		
		// update phaserBeams
		for(int i = 0; i < phaserBeams.size(); i++) {
			phaserBeams.get(i).update();
			if(phaserBeams.get(i).shouldRemove()) {
				phaserBeams.remove(i);
				i--;
			}
		}

//
//		// attempting turn
//		if (distanceToTurn() <= turnCount) {
//			turnCount = 0;
//		}

		// updating animation here...
		animation.update();

	}

	public void draw(Graphics2D g) {

		// if(notOnScreen())return;
		setMapPosition();

		// draw phaserBeams
				for(int i = 0; i < phaserBeams.size(); i++ ) {
					phaserBeams.get(i).draw(g);
				}
		
//		// draw boulder
//		for(int i = 0; i < boulder.size(); i++) {
//			boulder.get(i).draw(g);
//		}
				if (flinching) {
					long elapsed = (System.nanoTime() - flinchTimer) / 1000000;
					if (elapsed / 100 % 2 == 0) {
						return;
					}
				}

		super.draw(g);
	}

}
