package Entity.Enemies;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import javax.imageio.ImageIO;

import Audio.AudioPlayer;
import Entity.Animation;
import Entity.Enemy;
import Entity.GasCloud;
import Entity.Phaser;
import Entity.Player;
import GameState.GameStateManager;
import TileMap.TileMap;

public class Spore extends Enemy {

	// private BufferedImage[] sprites;
	// audio
	private HashMap<String, AudioPlayer> sfx;
	// animations
	private ArrayList<BufferedImage[]> sprites;

//	private boolean idle;
//	private boolean attacking;
	//private boolean turn;
	// private boolean isDead;

	// animation actions
	private static final int IDLE = 0;
	private static final int ATTACKING = 1;
	private int shootCount = 0;
	//private int attackRange = 30; // 90
	private int shootFreq;
	 private int shootDamage = 3;
	 private int gun = 1000;
	 private int maxGun = 1000;
	 private int shootCost = 300;
	// private ArrayList<Phaser> phaserBeams;
	private ArrayList<GasCloud> gasClouds;
	private Player player;
	 Random rand = new Random();

	// constructor
	public Spore(TileMap tm, GameStateManager gsm, Player p) {
		super(tm, gsm);
		this.player = p;
		this.score = 75;
		
		moveSpeed = 0; // 1.6
		maxSpeed = 0; // 2
		fallSpeed = .2;
		maxFallSpeed = 10;

		width = 30;
		height = 30;
		cwidth = 20; // real w and h ?
		cheight = 20;

		health = maxHealth = 8;
		// gun = maxGun = 5000;
		damage = 2;

		// these array values come from player sprite file frames. ( 2 for idle, 8 for
		// walking...) tut4 10min
		final int[] numFrames = { 3, 3 };

		sfx = new HashMap<String, AudioPlayer>();
		// sfx.put("svattack", new AudioPlayer("/SFX/svattack.mp3"));

		// phaserBeams = new ArrayList<Phaser>();
		gasClouds = new ArrayList<GasCloud>();
		// load sprites

		try {

			BufferedImage spritesheet = ImageIO.read(getClass().getResourceAsStream("/Sprites/Enemies/spore.gif"));
			sprites = new ArrayList<BufferedImage[]>();
			for (int i = 0; i < 2; i++) {
				BufferedImage[] bi = new BufferedImage[numFrames[i]];
				for (int j = 0; j < numFrames[i]; j++) {

					bi[j] = spritesheet.getSubimage(j * width, i * height, width, height);

				}

				sprites.add(bi);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		animation = new Animation();
		currentAction = IDLE;
		animation.setFrames(sprites.get(IDLE));
		animation.setDelay(300);

					sfx = new HashMap<String, AudioPlayer>();
					sfx.put("voice", new AudioPlayer("/SFX/sporevoice.mp3"));
//					sfx.put("grip", new AudioPlayer("/SFX/playegrip.mp3"));
//					sfx.put("phaser", new AudioPlayer("/SFX/playershoot.mp3"));

		right = true;
		facingRight = true;

//					int getHealth() { return health; }
//					public int getMaxHealth() { return maxHealth; }

	}

	public void playSound() {
		 sfx.get("voice").play();
	}

		public String getEnemySound() {
			return "voice";
		}

		public int timeToShoot() {
			
			return (int) Math.floor(Math.random() * shootFreq); // this affects gorn left and right frequency 800 default
		}
		public void setShootFreq(int i) {
			this.shootFreq = i;
		}


	private void getNextPosition() {

//			// movement
//			if (right) {
//
//				dx += moveSpeed; // had to invert these so snake would look right (+= and -= and <>)
//				if (dx > maxSpeed) {
//					dx = maxSpeed;
//
//				}
//			} else if (left) {
//
//				dx -= moveSpeed;
//				if (dx < -maxSpeed) {
//					dx = -maxSpeed;
//
//				}
//			}

		// falling
		if (falling) {
			dy += fallSpeed;
		}

		animation.update();

	}

	public void update(GameStateManager gsm) {

		gun += 2;
		shootCount++;
		
		// update position
		getNextPosition();
		checkTileMapCollision();
		setPosition(xtemp, ytemp);
//
//		if(attacking) {
//			currentAction = ATTACKING;
//		}


		// check attack has stopped
		if (currentAction == ATTACKING) {
			if (animation.hasPlayedOnce())
				setEnemyAttacking(false);
			
			// currentAction = WALKING;
			 attacking = false;
		}

		// check flinching
		if (flinching) {
			long elapsed = (System.nanoTime() - flinchTimer) / 1000000;
			if (elapsed > 400) {
				flinching = false;
			}
		}
		
		// attempting shoot
				if (timeToShoot() <= shootCount) {
					shootCount = 0;
					

					if (gun > maxGun)
						gun = maxGun;
					if (gun > shootCost) {
						// sfx.get("phaser").play(); //change this to gorn phaser sound, also declare
						// above...
						gun -= shootCost;
						GasCloud gs1 = new GasCloud(tileMap, gsm);	// 0 for player, 1 for enemy
						GasCloud gs2 = new GasCloud(tileMap, gsm);	// 0 for player, 1 for enemy
						GasCloud gs3 = new GasCloud(tileMap, gsm);	// 0 for player, 1 for enemy

						//gs1.setPosition(x - 30, y);	//left
						//gs2.setPosition(x + 30, y);	//right
						gs3.setPosition(x, y - 30);			//center
						
						//gasClouds.add(gs1);
						//gasClouds.add(gs2);
						gasClouds.add(gs3);


					}
		
				}
		
		
		
		//set animation
		if (attacking) {////////// might need to go in getNextPosition
			if(currentAction != ATTACKING) {
				currentAction = ATTACKING;
				animation.setFrames(sprites.get(ATTACKING));
				animation.setDelay(300);
				width = 30;
			}
			
			// animation.update();

		} else {
			if(currentAction != IDLE) {
				currentAction = IDLE;
				animation.setFrames(sprites.get(IDLE));
				animation.setDelay(300);
				width = 30;
			}
			
		}

		//	check gasCloud collisions
		for(int i = 0; i < gasClouds.size(); i++) {
			if(gasClouds.get(i).intersects(player)) {
				player.playerHit(this, shootDamage);
				gasClouds.get(i).setHit();
				break;
			}
		}
		
		// update gasClouds
		for(int i = 0; i < gasClouds.size(); i++) {
			gasClouds.get(i).update();
			if(gasClouds.get(i).shouldRemove()) {
				gasClouds.remove(i);
				i--;
			}
		}
		
		// update animation
		animation.update();

	}

	public void draw(Graphics2D g) {

		// if(notOnScreen())return;
		setMapPosition();

//			// draw phaserBeams
//					for(int i = 0; i < phaserBeams.size(); i++ ) {
//						phaserBeams.get(i).draw(g);
//					}
		for(int i = 0; i < gasClouds.size(); i++) {
			gasClouds.get(i).draw(g);
		}
//		// draw player
		if (flinching) {
			long elapsed = (System.nanoTime() - flinchTimer) / 1000000;
			if (elapsed / 100 % 2 == 0) {
				return;
			}
		}

		super.draw(g);
	}

}
