package Entity;

import java.util.ArrayList;

import GameState.GameStateManager;
import TileMap.TileMap;

public class Inventory extends Bill {

	private ArrayList<Item> item;
	
	
	
	public Inventory(TileMap tm, GameStateManager gsm) {
		super(tm, gsm);
		
		
	}

	public Item get(int i) {
		
			
		return item.get(i);
	}
	
	
}
