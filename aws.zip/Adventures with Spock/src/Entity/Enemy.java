package Entity;

import java.util.HashMap;

import Audio.AudioPlayer;
import GameState.GameStateManager;
import TileMap.*;

public abstract class Enemy extends MapObject {

	
	protected int score;
	protected int health;
	protected int maxHealth;
	protected boolean dead;
	protected int damage;
	protected int gun;
	protected int maxGun;
	protected double healthRegen;
	
	protected boolean flinching;
	protected long flinchTimer;
	protected boolean attacking;
	protected boolean boss;
	protected int type;
	protected boolean bossIsDead;

	
	// audio
	protected HashMap<String, AudioPlayer> sfx;
	protected HUD bossHud;
	
	//sfx = new HashMap<String, AudioPlayer>();
	//sfx.put("svattack", new AudioPlayer("/SFX/svattack.mp3"));
	
	
	
	
	
	public Enemy(TileMap tm, GameStateManager gsm) {
		super(tm, gsm);
	}
	
	public void setBoss(Boolean b) {
		this.boss = b;
	}
	
	public boolean isBoss() {
		return boss;
	}
	public void setBossDead(Boolean b) {
		this.bossIsDead = b;
	}
	public void setMaxHealth(int i) {
		this.health = this.maxHealth = i;
	}
	public boolean checkDead() {
		return dead;
	}
//	public void setHealthRegen(double d) {
//		this.healthRegen = d;
//	}
	
	public boolean bossIsDead() { return bossIsDead; }
	public boolean isDead() { return dead; }
	
	public int getDamage() { return damage; }
	public int getHealth() { return health; }
	public int getMaxHealth() { return maxHealth; }
	public int getGun() { return gun; }
	public int getMaxGun() { return maxGun; }
	
	public void playSound() {
		
	}
	public void playDeathSound() {}

	// getter for enemy score upon death
	public int getScore() {
		return score;
	}
	
	public void setEnemyAttacking(Boolean b) {
		this.attacking = b;
	}
	public boolean enemyAttacking() { return attacking; }
	
//	public HashMap getSound() {
//		return sfx;
//	}
	
	//this applies to enemies
	public void hit(GameStateManager gsm, int damage) {
		if(dead ||flinching) return;
		if(!dead) {
			
			health -= damage;
			if(health < 0) health = 0;
			if(health == 0) {
				dead = true;
				//gsm.addToScore(this.getScore());
				
				
				playDeathSound();
			}
			flinching = true;
			flinchTimer = System.nanoTime();
		}
		if(dead) {
			gsm.forever_score += score;
			System.out.println(getScore());
		}
		
	}
	
	public void update(GameStateManager gsm) {}
	
	
	
}
