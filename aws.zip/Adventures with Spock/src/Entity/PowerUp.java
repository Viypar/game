package Entity;

import java.util.HashMap;

import Audio.AudioPlayer;
import GameState.GameStateManager;
import TileMap.TileMap;

public abstract class PowerUp extends MapObject {

	protected int score;
	protected int health;
	protected int maxHealth;
	protected boolean used;
	protected double effect;
	protected boolean move;
	protected double multiplier;

	protected int type;

	// audio
	protected HashMap<String, AudioPlayer> sfx;
	

	// sfx = new HashMap<String, AudioPlayer>();
	// sfx.put("svattack", new AudioPlayer("/SFX/svattack.mp3"));

	public PowerUp(TileMap tm, GameStateManager gsm) {
		super(tm, gsm);
		
	}

	//getter
	public boolean isUsed() {
		return used;
	}

	public void setMultiplier(double d) {
		this.multiplier = d;
	}
	public double getMultiplier() {
		return multiplier;
	}

//	public void setEffect(double d) {
//		this.effect = d;
//	}
	
	public int getType() {
		return type;
	}
	
	public int getScore() {
		return score;
	}



	public void applyEffect(PowerUp ph) {

	}

	//setter
	public void isUsed(Boolean b) {
		used = b;
	}

	public void update(GameStateManager gsm) {
	}

	

}
