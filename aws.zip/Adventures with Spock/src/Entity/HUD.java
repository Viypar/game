package Entity;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;

import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import GameState.GameState;

public class HUD {

	private Player player;
	private Ship ship;
	private Enemy enemy;
	private Bill bill;
	private HUD removeHud;
	private BufferedImage pHud;
	private BufferedImage bHud;
	private BufferedImage sHud;
	private BufferedImage billHud;
	private BufferedImage inventoryHud;
	private BufferedImage tHud;
	private Font font;
	
	public HUD(Player p) {
		player = p;
		
		try {
			
			pHud = ImageIO.read(getClass().getResourceAsStream("/HUD/hud_player_small.gif"));
			
			font = new Font("Arial", Font.PLAIN, 12);
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}

	}
	
	//constructor for boss HUD
	public HUD(Enemy e) {
		enemy = e;
		try {
			
			bHud = ImageIO.read(getClass().getResourceAsStream("/HUD/hud_enemy.gif"));
			
		}catch(Exception es) {
			es.printStackTrace();
		}
	}
	
	// constructor for ship
	public HUD(Ship s) {
		ship = s;
		try {
			sHud = ImageIO.read(getClass().getResourceAsStream("/HUD/ship_hud.gif"));
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	// constructor for Bill
	public HUD(Bill b) {
		bill = b;
		try {
			billHud = ImageIO.read(getClass().getResourceAsStream("/HUD/hud_player_small.gif"));
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	
	
//	// constructor for timer
	public HUD(long c) {
		
		try {
			tHud = ImageIO.read(getClass().getResource("/HUD/timer_score_hud.gif"));
			font = new Font("Arial", Font.BOLD, 12);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void draw(GameState gs, Graphics2D g, int a) {
	
		if(a == 0) {
			g.drawImage(pHud, 0, 0, null);
			g.setFont(font);
			g.setColor(Color.WHITE);
			//g.drawString(player.getHealth() + "/" + player.getMaxHealth(),10, GamePanel.WIDTH-90);
			g.drawString((int)player.getHealth() + "/" + (int)player.getMaxHealth(), 30, 15);
			g.drawString(player.getGun() / 100 + "/" + player.getMaxGun() / 100, 30, 35);
			g.drawString(player.getCollectablesFound() + "/" + gs.getMaxCollectables(), 30, 55);
		}
		 if(a == 1) {
			g.drawImage(bHud, 225, 10, null);
			g.setFont(font);
			g.setColor(Color.BLACK);
			g.drawString((int)enemy.getHealth() + "/" + (int)enemy.getMaxHealth(), 250, 30);
			//g.drawString(enemy.getGun() / 100 + "/" + enemy.getMaxGun() / 100, 250, 55);
		}
		 if(a == 2) {
			g.drawImage(tHud, 140, 0, null);
			g.setFont(font);
			g.setColor(Color.WHITE);
			g.drawString(gs.getElapsed() / 1000 + "" , 160, 20);
			g.drawString(gs.getCurrentScore() + "", 190, 20);
			
		}
		 if(a == 3) {
				g.drawImage(sHud, 0, 0, null);
				g.setFont(font);
				g.setColor(Color.WHITE);
				//g.drawString(player.getHealth() + "/" + player.getMaxHealth(),10, GamePanel.WIDTH-90);
				g.drawString((int)ship.getHealth() + "/" + (int)ship.getMaxHealth(), 30, 15);
				g.drawString(ship.getGun() / 100 + "/" + ship.getMaxGun() / 100, 30, 35);
				g.drawString(ship.getCollectablesFound() + "/" + gs.getMaxCollectables(), 30, 55);
			}
		 if(a == 4) {
				g.drawImage(billHud, 0, 0, null);
				g.setFont(font);
				g.setColor(Color.WHITE);
				//g.drawString(player.getHealth() + "/" + player.getMaxHealth(),10, GamePanel.WIDTH-90);
				g.drawString((int)bill.getHealth() + "/" + (int)bill.getMaxHealth(), 30, 15);
				g.drawString(bill.getGun() / 100 + "/" + bill.getMaxGun() / 100, 30, 35);
				g.drawString(bill.getCollectablesFound() + "/" + gs.getMaxCollectables(), 30, 55);
			}
		 if(a == 5) {
				g.drawImage(inventoryHud, 150, 150, null);
				g.setFont(font);
				g.setColor(Color.WHITE);
				//g.drawString(player.getHealth() + "/" + player.getMaxHealth(),10, GamePanel.WIDTH-90);
				g.drawString((int)bill.getHealth() + "/" + (int)bill.getMaxHealth(), 150, 70);
				g.drawString(bill.getGun() / 100 + "/" + bill.getMaxGun() / 100, 150, 190);
				g.drawString(bill.getCollectablesFound() + "/" + gs.getMaxCollectables(), 150, 210);
			}
		 

	}
	
	public void draw(Inventory inv, Graphics2D g) {
		g.drawImage(inventoryHud, 150, 150, null);
		g.drawString(inv.get(0).toString(), 150, 180);
	}
	
	
	public void removeHud(Graphics2D g, HUD h) {
		this.removeHud = h;
		
	}
	
}
