package Entity;

import GameState.GameStateManager;
import TileMap.TileMap;

public class Item extends MapObject {

	public Item(TileMap tm, GameStateManager gsm) {
		super(tm, gsm);
		// TODO Auto-generated constructor stub
	}

	public void add(int i) {
		
	}
	
}
