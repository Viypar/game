package Entity;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.HashMap;

import javax.imageio.ImageIO;

import Audio.AudioPlayer;
import GameState.GameStateManager;
import TileMap.TileMap;

public class FireBlock extends Enemy{

	private BufferedImage[] sprites;
	
	private static final int IDLE = 0;
	
	
	
	
	
	
	
	// audio
	private HashMap<String, AudioPlayer> sfx;
	
	
	public FireBlock(TileMap tm, GameStateManager gsm) {
		super(tm, gsm);
		this.score = 25;
	
		//type = 0;	//0 = moving type, 1 = stationary type
		moveSpeed = 2;	//2
		maxSpeed = 3;	//2.5
		fallSpeed = .2;
		maxFallSpeed = 10;
		
		width = 90;	//tilesheet?
		height = 30;
		cwidth = 30;	//real w and h ?
		cheight = 25;
		
		
		health = maxHealth = 3;
		damage = 25;
		
		
		sfx = new HashMap<String, AudioPlayer>();
		sfx.put("svattack", new AudioPlayer("/SFX/svattack.mp3"));
		
		
		
		// load sprites
		
		try {
			
			BufferedImage spritesheet = ImageIO.read(getClass().getResourceAsStream("/Sprites/Enemies/fire_blob.gif"));
			sprites = new BufferedImage[3];
			for(int i = 0; i < sprites.length; i++) {
				sprites[i] = spritesheet.getSubimage(i * width, 0, width, height);
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		animation = new Animation();
		animation.setFrames(sprites);
		animation.setDelay(40);
		
		right = true;
		facingRight = true;
		

		
	}
	
	public void playSound() {
		sfx.get("svattack").play();
	}

	public void setType(int i) {
		type = i;	// 0 = moving, 1 = stationary
	}
	
	public void setSpeed(double s) {
		moveSpeed = s;
	}
	
	
//	public String getEnemySound() {
//		return "svattack";
//	}
	
	private void getNextPosition() {
		
		
		if(type == 0) {
			// movement
			if(left) {
				dx += moveSpeed;		// had to invert these so snake would look right (+= and -= and <>)
				if(dx > maxSpeed) {
					dx = maxSpeed;
				}
			}
			else if(right) {
				dx -= moveSpeed;
				if(dx < -maxSpeed) {
					dx = -maxSpeed;
				}
			}

			// falling
			if(falling) {
				dy += fallSpeed;
			}
		}
		else {
			facingRight = true;
		}

	}
	
	public void update(GameStateManager gsm) {
		
		// update position
		getNextPosition();
		checkTileMapCollision();
		setPosition(xtemp, ytemp);
		
		// check flinching
		if(flinching) {
			long elapsed = (System.nanoTime() - flinchTimer) / 1000000;
			if(elapsed > 400) {
				flinching = false;
			}
		}
		
		if(type == 0) {
			// if it hits a wall, go other direction
			if(right && dx == 0) {
				right = false;
				left = true;
				facingRight = false;
			}
			else if( left && dx == 0) {
				right = true;
				left = false;
				facingRight = true;
			}
		}

		
		// update animation
		animation.update();
		
	}
	
	public void draw(Graphics2D g) {
		
		//if(notOnScreen())return;
		setMapPosition();
		super.draw(g);
	}
	
	
	
}
