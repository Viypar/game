package Entity;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.HashMap;

import javax.imageio.ImageIO;

import Audio.AudioPlayer;
import GameState.GameStateManager;
import TileMap.TileMap;

public class UpgradeJump extends PowerUp {

	private BufferedImage[] sprites;
	// audio
	//private HashMap<String, AudioPlayer> sfx;
	
	
	public UpgradeJump(TileMap tm, GameStateManager gsm) {
		super(tm, gsm);
		this.score = 25;
		
		// type = 0; //0 = moving type, 1 = stationary type
		moveSpeed = 1; // 2
		maxSpeed = 1.25; // 2.5
		fallSpeed = .2;
		maxFallSpeed = 10;

		width = 30; // tilesheet?
		height = 30;
		cwidth = 20; // real w and h ?
		cheight = 20;

		//health = maxHealth = 1;
		

		sfx = new HashMap<String, AudioPlayer>();
		// sfx.put("svattack", new AudioPlayer("/SFX/svattack.mp3"));

		// load sprites

		try {

			BufferedImage spritesheet = ImageIO.read(getClass().getResourceAsStream("/Sprites/PowerUps/upgrade_jump.gif"));
			sprites = new BufferedImage[3];
			for (int i = 0; i < sprites.length; i++) {
				sprites[0] = spritesheet.getSubimage(i * width, 0, width, height);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		animation = new Animation();
		animation.setFrames(sprites);
		animation.setDelay(300);

		right = true;
		facingRight = true;

		
	}
	
	public void playSound() {
		// sfx.get("svattack").play();
	}

	public void setMovement(Boolean b) {
		this.move = b;
	}

	public void setSpeed(double s) {
		moveSpeed = s;
	}

	public void setMultiplier(double m) {
		this.multiplier = m;
	}
	
	public void setEffect(double d) {
		this.effect = d;
	}
	
	public void setType(int t) {
		this.type = t;
	}
	
	public void isUsed(Boolean b) {
		this.used = b;
	}

//	public String getEnemySound() {
//		return "svattack";
//	}

	private void getNextPosition() {

		if (move) {		//if type is true the powerUp object is allowed to move...scary thought
			// movement
			if (left) {
				dx += moveSpeed; // had to invert these so snake would look right (+= and -= and <>)
				if (dx > maxSpeed) {
					dx = maxSpeed;
				}
			} else if (right) {
				dx -= moveSpeed;
				if (dx < -maxSpeed) {
					dx = -maxSpeed;
				}
			}

			// falling
			if (falling) {
				dy += fallSpeed;
			}
			
			facingRight = true;
			
		}

	

	}

	public void update(GameStateManager gsm) {

		// update position
		getNextPosition();
		checkTileMapCollision();
		setPosition(xtemp, ytemp);

		if (move == true) {
			// if it hits a wall, go other direction
			if (right && dx == 0) {
				right = false;
				left = true;
				facingRight = false;
			} else if (left && dx == 0) {
				right = true;
				left = false;
				facingRight = true;
			}
		}

		// update animation
		animation.update();

	}

	public void draw(Graphics2D g) {

		// if(notOnScreen())return;
		setMapPosition();
		super.draw(g);
	}
	
	

}
