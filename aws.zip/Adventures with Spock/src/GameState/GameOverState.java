package GameState;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.Random;

import Audio.AudioPlayer;
import TileMap.Background;

public class GameOverState extends GameState{
	
	private Background bg;

	private int currentChoice = 0;
	private String[] options = { "Choose a Level?", " Save and QUIT" };
	private Color titleColor;
	private Font titleFont;

	private Font font;
	
	private AudioPlayer youAreRelieved;
	private AudioPlayer theOdds;
	private AudioPlayer iKnow;
	private AudioPlayer gorn_yell;
	private AudioPlayer up_sound = new AudioPlayer("/SFX/up_menu_sound.mp3");
	private AudioPlayer down_sound = new AudioPlayer("/SFX/down_menu_sound.mp3");
	private AudioPlayer select_sound = new AudioPlayer("/SFX/select_menu_sound.mp3");
	private AudioPlayer confirm_sound  = new AudioPlayer("/SFX/confirm_sound.mp3");
	//private int rand;
	
	private Save s;
	
	
	

	public GameOverState(GameStateManager gsm) {
		
		youAreRelieved = new AudioPlayer("/SFX/spokvoice_youarerelieved.mp3");
		theOdds = new AudioPlayer("/SFX/spokvoice_theOdds.mp3");
		iKnow = new AudioPlayer("/SFX/spokvoice_iKnow.mp3");
		gorn_yell = new AudioPlayer("/SFX/gorn_death.mp3");
		
		
		//gorn_yell.play();
		Random rand = new Random();
		int res = rand.nextInt(4);
		switch(res) {
		case 0:
			youAreRelieved.play();
			break;
		case 1:
			theOdds.play();
			break;
		case 2:
			iKnow.play();
			break;
		case 3:
			gorn_yell.play();
			
			default:
				youAreRelieved.play();
				break;
		}

		
		this.gsm = gsm;

		try {

			bg = new Background("/Backgrounds/awstitlebackground.gif", 1);
			bg.setVector(-.3, 0);	//(-0.1, 0)

			titleColor = new Color(128, 128, 128);
			titleFont = new Font("Courier New", Font.PLAIN, 22);
			font = new Font("Courier New", Font.PLAIN, 12);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void init() {
	}

	public void update() {
		bg.update();
	}

	public void draw(Graphics2D g) {

		// draw bg
		bg.draw(g);

		// draw title
		g.setColor(titleColor);
		g.setFont(titleFont);
		g.drawString("GAME OVER", 115, 110);

		// draw menu
		g.setFont(font);
		for (int i = 0; i < options.length; i++) {
			if (i == currentChoice) {
				g.setColor(Color.WHITE);
			} else {
				g.setColor(Color.GRAY);
			}
			g.drawString(options[i], 60 + i * 120, 170);
		}
		
	
	}

	private void select() {
		if (currentChoice == 0) {
			// Start // Level Select
			gsm.setState(GameStateManager.LEVELSELECTSTATE);	
		}
		if(currentChoice == 1) {
			try {
				s = new Save(gsm);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			confirm_sound.play();
			System.exit(0);
		}

	}

	public void keyPressed(int k) {
		if (k == KeyEvent.VK_ENTER) {
			select_sound.play();
			select();
		}
		if (k == KeyEvent.VK_LEFT) {
			down_sound.play();
			currentChoice--;
			if( currentChoice == -1) {
				currentChoice = options.length-1;
			}
		}
		if(k == KeyEvent.VK_RIGHT ){
			up_sound.play();
			currentChoice++;
			if(currentChoice == options.length) {
				currentChoice = 0;
			}
		}

	}

	public void keyReleased(int k) {
	}

	
	

}
