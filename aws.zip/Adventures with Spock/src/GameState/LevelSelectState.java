package GameState;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.ArrayList;

import Audio.AudioPlayer;
import TileMap.Background;

public class LevelSelectState extends GameState {

	private Background bg;
	private long totalBest;
//	private int numOfLevels = 17;
//	private boolean locked;
	
	private int currentChoice = 0;
//	private ArrayList<String> stringUnlocked;
//	private ArrayList<String> stringLocked;
//	private ArrayList<GameState> gameStates;
	private String[] options = { "Vulcan", "Gamma Vega", "Denova", "Beta Prime", "Deathrow", "Collapsed Star", "No Return", "Save", "Back" };
	//private Color titleColor;
	private Font titleFont;

	private Font font;
	private Font timeFont;
	
	private Save s;
	private AudioPlayer up_sound = new AudioPlayer("/SFX/up_menu_sound.mp3");
	private AudioPlayer down_sound = new AudioPlayer("/SFX/down_menu_sound.mp3");
	private AudioPlayer select_sound = new AudioPlayer("/SFX/select_menu_sound.mp3");
	private AudioPlayer confirm_sound  = new AudioPlayer("/SFX/confirm_sound.mp3");
	
	
	public LevelSelectState(GameStateManager gsm) {
		this.gsm = gsm;
		
//		for(int i = 11; i < numOfLevels; i ++) {
//			
//			// if level is not locked add it to arraylist of names to display on level select screen.
//			if(!gs.get(i).isLocked()) {
//				stringUnlocked.add(gs.get(i).getStateName());
//				
//			}
//			else {
//				stringLocked.add(gs.get(i).getStateName());
//			}
//			
//			
//		}
		
		try {

			bg = new Background("/Backgrounds/levelmenumk2.gif", 1);
			bg.setVector(0, 0);	//(-0.1, 0)

			//titleColor = new Color(128, 128, 128);
			titleFont = new Font("Lucida Sans", Font.PLAIN, 20);
			font = new Font("Lucida Sans", Font.PLAIN, 10);
			timeFont = new Font("Century Gothic", Font.PLAIN, 12);

		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void init() {
	}

	public void update() {
		bg.update();
	}
	
	public void draw(Graphics2D g) {

		// draw bg
		bg.draw(g);

//		// draw title
		g.setColor(Color.WHITE);
		g.setFont(titleFont);
		g.drawString("SELECT LEVEL", 30, 30);

		//int k = stringUnlocked.size();
		
		
		// draw level selections
		g.setFont(font);
		for (int i = 0; i < options.length; i++) {
			
			if (i == currentChoice) {
				g.setColor(Color.WHITE);
			} else {
				g.setColor(Color.GRAY);
			}
			
			
			g.drawString(options[i], 90, 52 + i * 22);	//g.drawString(options[i], 85 + i * 120, 170);
		}
		
//		for( int j = 0; j < (7 - k); j++) {
//			g.drawString(stringLocked.get(j), 70,  82 + ((j+k) * 22));
//		}
		
		//g.drawString(options[7], 150, 230);
		
		//int temp = (int)gsm.level_1_best;
		
		
		g.setFont(titleFont);
		g.setColor(Color.WHITE);
		g.drawString("Records", 210, 30);
		g.setFont(font);
		g.drawString("Best / Max    Time", 190, 40);
		g.setFont(font);
		// draw best times
		
		// score
		g.drawString(gsm.level_1_max_score + " / 2500", 190, 52);
		g.drawString(gsm.level_2_max_score + " / 2525", 190, 74);
		g.drawString(gsm.level_3_max_score + " / 3000", 190, 96);
		g.drawString(gsm.level_4_max_score + " / 3725", 190, 118);
		g.drawString(gsm.level_5_max_score + " / 2700", 190, 140);
		g.drawString(gsm.level_6_max_score + " / 2975", 190, 162);
		g.drawString(gsm.level_7_max_score + " / 3775", 190, 184);
		
		
		// time
		g.drawString(gsm.level_1_best / 1000 + " s", 260, 52);
		g.drawString(gsm.level_2_best / 1000 + " s", 260, 74);
		g.drawString(gsm.level_3_best / 1000 + " s", 260, 96);
		g.drawString(gsm.level_4_best / 1000  + " s", 260, 118);
		g.drawString(gsm.level_5_best / 1000  + " s", 260, 140);
		g.drawString(gsm.level_6_best / 1000  + " s", 260, 162);
		g.drawString(gsm.level_7_best / 1000  + " s", 260, 184);
		
		// totalling them up
		calcTotalTime();
		
		g.setColor(Color.WHITE);
		g.drawString("Total: " + totalBest / 1000  + " s" , 230, 210);
		g.setFont(timeFont);
		g.drawString(gsm.getVersion(), 200, 230);
		
		
		
		
		
		
	}
	
	
	
	public void calcTotalTime() {
		this.totalBest = (gsm.level_1_best + gsm.level_2_best + gsm.level_3_best + gsm.level_4_best + gsm.level_5_best + gsm.level_6_best + gsm.level_7_best );
	}

	private void select() throws IOException {
		if (currentChoice == 0) {
			// Level 1
			
			gsm.setState(GameStateManager.LEVEL3STATE);	//Escape from Vulcan
		}
		if (currentChoice == 1) {
			// Level 2
			gsm.setState(GameStateManager.LEVEL4STATE);	//Escape from Gamma Vega
		}
		if (currentChoice == 2) {
			// Level 3
			gsm.setState(GameStateManager.LEVELDENOVASTATE);	//moon (level 2)
		}
		if (currentChoice == 3) {
			// Level 4
			gsm.setState(GameStateManager.LEVELBETAPRIMESTATE);	// test2 level
		}
		if (currentChoice == 4) {
			// Level 5
			gsm.setState(GameStateManager.LEVELDEATHROWSTATE);
		}
		if (currentChoice == 5) {
			// Level 6
			gsm.setState(GameStateManager.LEVELCOLLAPSEDSTARSTATE);
		}
		if (currentChoice == 6) {
			// Level 7
			gsm.setState(GameStateManager.LEVELNORETURNSTATE);
		}
		if (currentChoice == 7) {
			s = new Save(gsm);
			confirm_sound.play();
			gsm.setState(GameStateManager.LEVELSELECTSTATE);
		}
		if(currentChoice == 8) {
			// back to main menu
			gsm.setState(GameStateManager.MENUSTATE);
			
		}
		
	}

	public void keyPressed(int k) throws IOException {
		if (k == KeyEvent.VK_ENTER) {
			select_sound.play();
			select();
		}
		if (k == KeyEvent.VK_UP) {
			up_sound.play();
			currentChoice--;
			if( currentChoice == -1) {
				currentChoice = options.length - 1;
			}
		}
		if(k == KeyEvent.VK_DOWN ){
			down_sound.play();
			currentChoice++;
			if(currentChoice == options.length) {
				currentChoice = 0;
			}
		}
		
	}

	public void keyReleased(int k) {
	}


}
