package GameState;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import Audio.AudioPlayer;
import Entity.Collectable;
import Entity.Enemy;
import Entity.Explosion;
import Entity.HUD;
import Entity.HealthPack;
import Entity.PhaserUpgrade;
import Entity.Player;
import Entity.PowerUp;
import Entity.Star;
import Entity.Enemies.Gorn;
import Entity.Enemies.Spore;
import Main.GamePanel;
import TileMap.Background;
import TileMap.TileMap;

public class LevelDenovaState extends GameState {

	private TileMap tileMap;
	private Background bg;

	private Player player;
	private boolean bossIsDead = false;

	private ArrayList<Enemy> enemies;
	private ArrayList<PowerUp> powerUps;
	private ArrayList<Collectable> collectables;
	private ArrayList<Explosion> explosions;

	private HUD hud;
	private HUD bossHud;
	private HUD timerHud;

	private AudioPlayer bgMusic;
	public int mc;
	private AudioPlayer puSfx;
	private AudioPlayer cSfx;

	public LevelDenovaState(GameStateManager gsm) {
		this.gsm = gsm;
		init();
	}

	@Override
	public void init() {

		// audio mute
		//this.mute = true;
		
		// setting max number of collectables for this level
		this.maxCollectables = 4;

		tileMap = new TileMap(30);
		tileMap.loadTiles("/Tilesets/denovatiles.gif");
		tileMap.loadMap("/Maps/level-denova-1.map");
		tileMap.setPosition(0, 0);
		tileMap.setTween(.04); // 0.07

		bg = new Background("/Backgrounds/denova_background.gif", 0.05); // todo

		player = new Player(tileMap, gsm);
		player.setPosition(2950, 220); // 2940,220

		populateEnemies();
		populatePowerUps();
		populateCollectables();

		explosions = new ArrayList<Explosion>();

		hud = new HUD(player);
		timerHud = new HUD(elapsed);

		bgMusic = this.level_music_danger1;
		puSfx = new AudioPlayer("/SFX/spokvoice_find_2.mp3");
		cSfx = new AudioPlayer("/SFX/collectable_found.mp3");
		
		if(!this.getMute()) {
			bgMusic.play();
			mc = 0;
		}
		
		startTimer = System.nanoTime();
		

	}

	private void populateEnemies() {

		enemies = new ArrayList<Enemy>();

		Spore spore;
		Point[] sporePoints = new Point[] { new Point(2955, 155), new Point(2685, 50),
				new Point(2710, 140), new Point(2580, 260), new Point(2480, 140), new Point(2300, 100),
				new Point(2250, 150), new Point(2190, 70), new Point(2130, 260), new Point(2025, 80),
				new Point(1910, 170), new Point(1695, 260), new Point(1635, 200), new Point(1455, 50),
				new Point(1425, 195), new Point(1335, 170), new Point(625, 165), new Point(630, 260),
				new Point(380, 225)

		};
		Gorn gorn;
		Point[] gPoints = new Point[] {
//			//new Point(5460, 210),
				new Point(80, 210)

		};

		// spore
		for (int i = 0; i < sporePoints.length; i++) {
			spore = new Spore(tileMap, gsm, player);
			spore.setPosition(sporePoints[i].getX(), sporePoints[i].y);
			spore.setBoss(false);
			spore.setShootFreq(8000);
			enemies.add(spore);

		}

		// gorn
		for (int i = 0; i < gPoints.length; i++) {
			gorn = new Gorn(tileMap, gsm, player);
			gorn.setPosition(gPoints[i].x, gPoints[i].y);
			gorn.setBoss(true);
			gorn.setMaxHealth(40);
			if (gorn.isBoss()) {
				bossHud = new HUD(gorn);
			}
			enemies.add(gorn);
		}

	}

	// populating power ups
	private void populatePowerUps() {
		powerUps = new ArrayList<PowerUp>();
		HealthPack hp;
		PhaserUpgrade pu;

		Point[] hPoints = new Point[] { new Point(330, 50)

		};

		Point[] pPoints = new Point[] { new Point(2770, 250) };

		for (int i = 0; i < hPoints.length; i++) {
			hp = new HealthPack(tileMap, gsm);
			hp.setPosition(hPoints[i].x, hPoints[i].y);
			hp.setMovement(false);
			hp.setMultiplier(2);
			hp.setType(0); // sending 0 for health effects, 1 for phaser effects
			powerUps.add(hp);

		}

		for (int i = 0; i < pPoints.length; i++) {
			pu = new PhaserUpgrade(tileMap, gsm);
			pu.setPosition(pPoints[i].x, pPoints[i].y);
			pu.setMovement(false);
			pu.setMultiplier(1.5);
			pu.setType(1); // sending 0 for health effects, 1 for phaser effects
			powerUps.add(pu);

		}

	}

	// populating collectables
	private void populateCollectables() {
		collectables = new ArrayList<Collectable>();
		Star s;

		Point[] starPoints = new Point[] {
				// new Point(2770, 240),
				new Point(2130, 50),
				new Point(1690, 160), new Point(1450, 260), new Point(990, 170) };

		for (int i = 0; i < starPoints.length; i++) {
			s = new Star(tileMap, gsm);
			s.setPosition(starPoints[i].x, starPoints[i].y);
			s.setMovement(false);
			s.setEffect(0);
			s.setType(0); // 0 for stars....
			collectables.add(s);

		}

	}

	@Override
	public void update() {

		// update timer hud
		this.elapsed = ( System.nanoTime() - startTimer) / 1000000;
		this.currentScore = gsm.level_3_current_score;
		
		if(!this.getMute()) {
//			// audio update
			mc++;
			if (mc >= 375) {
				bgMusic.play();
				mc = 0;
			}
		}

		// check quit
		if (player.getQuit()) {
			bgMusic.stop();
			gsm.setState(4); // (4) levelselectstate (0) main menu
		}

		// update player
		player.update();

		tileMap.setPosition(GamePanel.WIDTH / 2 - player.getx(), GamePanel.HEIGHT / 2 - player.gety());

		// set background
		bg.setPosition(tileMap.getx(), tileMap.gety());

		// attack enemies
		player.checkAttack(enemies, powerUps, collectables);
		if (player.checkDead()) {

			gsm.setState(3);///////////////////////// to do death screen
			bgMusic.stop();
		}

		if (player.getx() <= 40 && player.gety() > 200) {
			// spokvictorySfx.play();
			if (bossIsDead) {
				
				finalTime = getElapsed();
				gsm.level_3_time = finalTime;
				gsm.level_3_current_score += 1000;
				gsm.forever_score += 1000;
				bgMusic.stop();
				gsm.setState(5);
			}
		}

		// update all enemies
		for (int i = 0; i < enemies.size(); i++) {
			Enemy e = enemies.get(i);
			e.update(gsm);
			if (e.isDead()) {
				gsm.level_3_current_score += e.getScore();
				gsm.forever_score += e.getScore();
				if (e.isBoss()) {
					bossIsDead = true;
				}

				enemies.remove(i);
				i--;
				explosions.add(new Explosion(e.getx(), e.gety()));

			}

		}

		// update all powerUps
		for (int i = 0; i < powerUps.size(); i++) {
			PowerUp ph = powerUps.get(i);
			ph.update(gsm);
			if (ph.isUsed()) {
				puSfx.play();
				gsm.level_3_current_score += ph.getScore();
				gsm.forever_score += ph.getScore();
				powerUps.remove(i);
				i--;
				// could add powerUp animation here for when player gets it... #todo...
				// could alter gamestate here if you wanted....scary thots

			}
		}

		// update all collectables
		for (int i = 0; i < collectables.size(); i++) {
			Collectable c = collectables.get(i);
			c.update(gsm);
			if (c.isUsed()) {
				gsm.level_3_current_score += c.getScore();
				gsm.forever_score += c.getScore();
				cSfx.play();
				if (player.getCollectablesFound() >= maxCollectables) {
					
					gsm.level_3_current_score += 750;
					gsm.forever_score += 750;
					finalTime = getElapsed();
					gsm.level_3_time = finalTime;
					bgMusic.stop();
					gsm.setState(5);
				}

				// play sound that player got it
				collectables.remove(i);
				i--;

			}
		}

		// update all explosions
		for (int i = 0; i < explosions.size(); i++) {
			explosions.get(i).update();
			if (explosions.get(i).shouldRemove()) {
				explosions.remove(i);
				i--;
			}
		}

	}

	@Override
	public void draw(Graphics2D g) {
		// draw background
		bg.draw(g);

		// draw tileMap
		tileMap.draw(g);

		// draw player
		player.draw(g);

		// draw enemies
		for (int i = 0; i < enemies.size(); i++) {
			enemies.get(i).draw(g);
		}
//				
		// draw power ups
		for (int i = 0; i < powerUps.size(); i++) {
			powerUps.get(i).draw(g);
		}

		for (int i = 0; i < collectables.size(); i++) {
			collectables.get(i).draw(g);
		}

		// draw explosions
		for (int i = 0; i < explosions.size(); i++) {
			explosions.get(i).setMapPosition((int) tileMap.getx(), (int) tileMap.gety());
			explosions.get(i).draw(g);
		}

		// draw HUD
		hud.draw(this, g, 0); // passing 0 for player, 1 for boss, and 2 for timer huds.
		if (player.getx() <= 290) {
			bossHud.draw(this, g, 1);
		}
		timerHud.draw(this, g, 2);

	}

	@Override
	public void keyPressed(int k) {
		if (k == KeyEvent.VK_LEFT) {
			player.setLeft(true);
		}
		if (k == KeyEvent.VK_RIGHT) {
			player.setRight(true);
		}
		if (k == KeyEvent.VK_UP) {
			player.setUp(true);
		}
		if (k == KeyEvent.VK_DOWN) {
			player.setDown(true);
		}
		if (k == KeyEvent.VK_SPACE) {
			player.setJumping(true);
		}
		if (k == KeyEvent.VK_SHIFT) {
			player.setGliding(true);
		}
		if (k == KeyEvent.VK_S) {
			player.setGripping(true);
		}
		if (k == KeyEvent.VK_F) {
			player.setShooting(true);
		}
		if (k == KeyEvent.VK_P) {
			player.setQuit(true);
		}

	}

	@Override
	public void keyReleased(int k) {
		if (k == KeyEvent.VK_LEFT) {
			player.setLeft(false);
		}
		if (k == KeyEvent.VK_RIGHT) {
			player.setRight(false);
		}
		if (k == KeyEvent.VK_UP) {
			player.setUp(false);
		}
		if (k == KeyEvent.VK_DOWN) {
			player.setDown(false);
		}
		if (k == KeyEvent.VK_SPACE) {
			player.setJumping(false);
		}
		if (k == KeyEvent.VK_SHIFT) {
			player.setGliding(false);
		}
		if (k == KeyEvent.VK_S) {
			player.setGripping(false);
		}
		if (k == KeyEvent.VK_F) {
			player.setShooting(false);
		}

	}

	

}
