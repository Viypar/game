package GameState;

import java.awt.Graphics2D;
import java.io.IOException;
import java.util.ArrayList;

import Audio.AudioPlayer;

public abstract class GameState {


	
	protected GameStateManager gsm;
	protected boolean lock;
	protected long startTimer;
	protected long elapsed;
	protected long finalTime;
	protected String stateName;
	protected int maxCollectables;
	protected long currentScore;
	//protected int maxPossibleScore = 1000;
	protected ArrayList<GameState> gs;
	
	protected boolean mute;
	
	protected AudioPlayer up_sound = new AudioPlayer("/SFX/up_menu_sound.mp3");
	protected AudioPlayer down_sound = new AudioPlayer("/SFX/down_menu_sound.mp3");
	protected AudioPlayer select_sound = new AudioPlayer("/SFX/select_menu_sound.mp3");
	
	protected AudioPlayer level_music_danger1 = new AudioPlayer("/Music/danger1.mp3");
	protected AudioPlayer level_music_level1 = new AudioPlayer("/Music/level1.mp3");
	protected AudioPlayer level_music_level2 = new AudioPlayer("/Music/level2.mp3");
	
	
	
	
	public boolean getMute() { return mute; }
	public boolean isLocked() { return lock; }
	public String getStateName() { return stateName; }
	public long getElapsed() { return elapsed; }
	public void setFinalTime(long prevTime) {
		this.finalTime = prevTime;
	}
	public long getFinalTime() { return finalTime;}
	public long getCurrentScore() {
		return currentScore;
	}
//	public void addtoMaxPossibleScore(int i) {
//		maxScorePossible += i;
//	}
	
	//getters and setters for collectables
	public int getMaxCollectables() { return maxCollectables; }
	public void setMaxCollectables(int i) {
		this.maxCollectables = i;
	}
	
	
	
	
	
	
	public abstract void init();
	public abstract void update();
	public abstract void draw(Graphics2D g);
	public abstract void keyPressed(int k) throws IOException;
	public abstract void keyReleased(int k);
	
	
	
	
}
