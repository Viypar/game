package GameState;

import TileMap.Background;
import java.awt.event.KeyEvent;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;



public class Pause extends GameState{

	private Background bg;

	private int currentChoice = 0;
	private String[] options = { "Continue", "Exit" };
	private Color titleColor;
	private Font titleFont;

	private Font font;

	public Pause(GameStateManager gsm) {

		this.gsm = gsm;

		try {

			bg = new Background("/Backgrounds/spacebg.gif", 1);
			bg.setVector(0, 0);	//(-0.1, 0)

			titleColor = new Color(128, 128, 128);
			titleFont = new Font("Century Gothic", Font.PLAIN, 26);
			font = new Font("Times New Roman", Font.PLAIN, 16);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void init() {
	}

	public void update() {
		bg.update();
	}

	public void draw(Graphics2D g) {

		// draw bg
		bg.draw(g);

		// draw title
		g.setColor(titleColor);
		g.setFont(titleFont);
		g.drawString("Pause", 100, 100);

		// draw menu
		g.setFont(font);
		for (int i = 0; i < options.length; i++) {
//			if (i == currentChoice) {
//				g.setColor(Color.WHITE);
//			} else {
//				g.setColor(Color.GRAY);
//			}
			g.drawString(options[i], 125, 120 + i * 15);
		}
		
		g.setColor(Color.WHITE);
		g.drawString("BACK", 145, 200);
	}

	private void select() {
		if (currentChoice == 0) {
			// Start // Level Select
			gsm.setState(GameStateManager.MENUSTATE);	
		}

	}

	public void keyPressed(int k) {
		if (k == KeyEvent.VK_ENTER) {
			select();
		}

	}

	public void keyReleased(int k) {
	}


	
	
	
}
