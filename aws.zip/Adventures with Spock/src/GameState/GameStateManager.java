package GameState;

import java.awt.Graphics2D;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;



public class GameStateManager {

	private String version = "Version Beta 12";
	private GameState[] gameStates;
	
	private int currentState;
	private int prevState;
	private long fin;
	
	public long times_played;
	//public int currentScore;
	public long forever_score;
	
	public long level_1_current_score;
	public long level_1_max_score = 0;
	public long level_2_current_score;
	public long level_2_max_score = 0;
	public long level_3_current_score;
	public long level_3_max_score = 0;
	public long level_4_current_score;
	public long level_4_max_score = 0;
	public long level_5_current_score;
	public long level_5_max_score = 0;
	public long level_6_current_score;
	public long level_6_max_score = 0;
	public long level_7_current_score;
	public long level_7_max_score = 0;


	
	
	
	public long level_1_time;
	public long level_1_best = 99999999;
	public long level_2_time;
	public long level_2_best = 99999999;
	public long level_3_time;
	public long level_3_best = 99999999;
	public long level_4_time;
	public long level_4_best = 99999999;
	public long level_5_time;
	public long level_5_best = 99999999;
	public long level_6_time;
	public long level_6_best = 99999999;
	public long level_7_time;
	public long level_7_best = 99999999;

	

	
	public static final int NUMGAMESTATES = 20;

	public static final int MENUSTATE = 0;
	public static final int HELPSTATE = 1;
	public static final int PAUSESTATE = 2;
	public static final int GAMEOVERSTATE = 3;
	public static final int LEVELSELECTSTATE = 4;
	public static final int LEVELCOMPLETESTATE = 5;
	public static final int HOWTOPLAY1STATE = 6;
	public static final int HOWTOPLAY2STATE = 7;
	public static final int HOWTOPLAY3STATE = 8;
	public static final int HOWTOPLAY4STATE = 9;
	public static final int HOWTOPLAY5STATE = 10;

	public static final int LEVEL3STATE = 11;
	public static final int LEVEL4STATE = 12;
	public static final int LEVELDENOVASTATE = 13;
	public static final int LEVELBETAPRIMESTATE = 14;
	public static final int LEVELDEATHROWSTATE = 15;
	public static final int LEVELCOLLAPSEDSTARSTATE = 16;
	public static final int LEVELNORETURNSTATE = 17;
	public static final int DISPLAYENEMYSTATE = 18;
	public static final int DISPLAYLEVELOBJECTIVESTATE = 19;
	
	

	public ArrayList<String> inFile;
	public String absolutePath;
	//public String pathName = "C:\\Users\\Pwatk\\Nextcloud\\Jacob and I Projects\\Adventures with Spok\\Install\\gamesave.txt";
	//public String pathName = "C:\\Users\\swdru\\2d_sidescroll_game\\Adventures with Spock\\gamesave.txt";
	//public String pathName = "%appdata%\\Adventures with Spock\\gamesave.txt";
	

	//private String pathName = "C:\\Users\\gdhen\\java stuff\\GAME VERSIONS\\gamesave.txt";
	//private String pathName = "\\Adventures with Spock\\src\\GameState\\gamesave.txt";
	//private String pathName = "\\Saves\\gamesave.txt";
	private String pathName = "C:\\Users\\Public\\Adventures with Spock\\gamesave.txt";
	
	

	public GameStateManager() {
				
	
		
		gameStates = new GameState[NUMGAMESTATES];

		currentState = MENUSTATE;
		loadState(currentState);
		
		inFile = new ArrayList<String>();
		
		
		
		
		// try to read best times
		try {
			
//			Path p = Paths.get(absolutePath); Paths API...?
//			Path folder = p.getParent();
//			System.out.println(folder.toString());
			
			
			File file = new File(pathName);
			
			absolutePath = file.getAbsolutePath();
			//System.out.println(absolutePath);
			Scanner s = new Scanner(file);
			while(s.hasNextLine()) {
				String data = s.nextLine();
				//System.out.println(data);
								
				inFile.add(data);
			}
			
			this.times_played = Long.parseLong(inFile.get(0));
			this.forever_score = Long.parseLong(inFile.get(1));
			this.level_1_max_score = Long.parseLong(inFile.get(2));
			this.level_2_max_score = Long.parseLong(inFile.get(3));
			this.level_3_max_score = Long.parseLong(inFile.get(4));
			this.level_4_max_score = Long.parseLong(inFile.get(5));
			this.level_5_max_score = Long.parseLong(inFile.get(6));
			this.level_6_max_score = Long.parseLong(inFile.get(7));
			this.level_7_max_score = Long.parseLong(inFile.get(8));
			
			this.level_1_best = Long.parseLong(inFile.get(9));
			this.level_2_best = Long.parseLong(inFile.get(10));
			this.level_3_best = Long.parseLong(inFile.get(11));
			this.level_4_best = Long.parseLong(inFile.get(12));
			this.level_5_best = Long.parseLong(inFile.get(13));
			this.level_6_best = Long.parseLong(inFile.get(14));
			this.level_7_best = Long.parseLong(inFile.get(15));
		
			
			// attempting play counter
			times_played += 1;
//			total_score = getTotalScore();
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	private void loadState(int state) {

		if (state == MENUSTATE) {			
			gameStates[state] = new MenuState(this);

		} else if (state == HELPSTATE) {
			gameStates[state] = new Help(this);
		} else if (state == PAUSESTATE) {
			gameStates[state] = new Pause(this);
		} else if (state == GAMEOVERSTATE) {
			gameStates[state] = new GameOverState(this);
		} else if (state == LEVELSELECTSTATE) {
			gameStates[state] = new LevelSelectState(this);
		} else if (state == LEVELCOMPLETESTATE) {
			gameStates[state] = new LevelCompleteState(this, prevState);
		} else if (state == HOWTOPLAY1STATE) {
			gameStates[state] = new HowToPlay1State(this);
		} else if (state == HOWTOPLAY2STATE) {
			gameStates[state] = new HowToPlay2State(this);
		} else if (state == HOWTOPLAY3STATE) {
			gameStates[state] = new HowToPlay3State(this);
		} else if (state == HOWTOPLAY4STATE) {
			gameStates[state] = new HowToPlay4State(this);
		} else if (state == HOWTOPLAY5STATE) {
			gameStates[state] = new HowToPlay5State(this);
		} else if (state == LEVEL3STATE) {
			gameStates[state] = new Level3State(this);
		} else if (state == LEVEL4STATE) {
			gameStates[state] = new Level4State(this);
		} else if (state == LEVELDENOVASTATE) {
			gameStates[state] = new LevelDenovaState(this);
		} else if (state == LEVELBETAPRIMESTATE) {
			gameStates[state] = new LevelBetaPrimeState(this);
		} else if (state == LEVELDEATHROWSTATE) {
			gameStates[state] = new LevelDeathRowState(this);
		} else if (state == LEVELCOLLAPSEDSTARSTATE) {
			gameStates[state] = new LevelCollapsedStarState(this);
		} else if (state == LEVELNORETURNSTATE) {
			gameStates[state] = new LevelNoReturnState(this);
		} else if (state == DISPLAYENEMYSTATE) {
			gameStates[state] = new DisplayEnemyState(this);
		} else {
			gameStates[state] = new MenuState(this); // default catch
		}
	}

	private void unloadState(int state) {
		gameStates[state] = null;
	}

	public void setState(int state) {
		prevState = currentState;
		unloadState(currentState);
		currentState = state;
		loadState(currentState);

	}

	public int getCurrGameState() {
		return currentState;
	}
	
	public String getGameStateString(int i) {
		String temp = "Escape From Vulcan";
		switch(i) {
		
		case 11:
			temp = "Escape from Vulcan";
			break;
			
		case 12:
			temp = "Escape from Gamma Vega";
			break;
			
		case 13:
			temp = "Escape from Denova";
			break;
			
		case 14:
			temp = "Escape from Beta Prime";
			break;
			
		case 15:
			temp = "Deathrow";
			break;
			
		case 16:
			temp = "Collapsed Star";
			break;
			
		case 17:
			temp = "No Return";
			break;
			
			}
		
		return temp;
		
		
	}
	
	// attempting to save best times
	public void calculateBestTime(int level) {
		switch(level) {
		case 1:
			if(level_1_best == 99999999) {
				level_1_best = level_1_time;
			}
			if(level_1_time < level_1_best) {
				level_1_best = level_1_time;
			}
			break;
		case 2:
			if(level_2_best == 99999999) {
				level_2_best = level_2_time;
			}
			if(level_2_time < level_2_best) {
				level_2_best = level_2_time;
			}
			break;
		case 3:
			if(level_3_best == 99999999) {
				level_3_best = level_3_time;
			}
			if(level_3_time < level_3_best) {
				level_3_best = level_3_time;
			}
			break;
		case 4:
			if(level_4_best == 99999999) {
				level_4_best = level_4_time;
			}
			if(level_4_time < level_4_best) {
				level_4_best = level_4_time;
			}
			break;
		case 5:
			if(level_5_best == 99999999) {
				level_5_best = level_5_time;
			}
			if(level_5_time < level_5_best) {
				level_5_best = level_5_time;
			}
			break;
		case 6:
			if(level_6_best == 99999999) {
				level_6_best = level_6_time;
			}
			if(level_6_time < level_6_best) {
				level_6_best = level_6_time;
			}
			break;
		case 7:
			if(level_7_best == 99999999) {
				level_7_best = level_7_time;
			}
			if(level_7_time < level_7_best) {
				level_7_best = level_7_time;
			}
			break;
	
		}
		
	}
	
	// attempting to save best scores
		public void calculateBestScore(int level) {
			switch(level) {
			case 1:
				if(level_1_max_score == 0) {
					level_1_max_score = level_1_current_score;
				}
				if(level_1_max_score < level_1_current_score) {
					level_1_max_score = level_1_current_score;
				}
				break;
			case 2:
				if(level_2_max_score == 0) {
					level_2_max_score = level_2_current_score;
				}
				if(level_2_max_score < level_2_current_score) {
					level_2_max_score = level_2_current_score;
				}
				break;
			case 3:
				if(level_3_max_score == 0) {
					level_3_max_score = level_3_current_score;
				}
				if(level_3_max_score < level_3_current_score) {
					level_3_max_score = level_3_current_score;
				}
				break;
			case 4:
				if(level_4_max_score == 0) {
					level_4_max_score = level_4_current_score;
				}
				if(level_4_max_score < level_4_current_score) {
					level_4_max_score = level_4_current_score;
				}
				break;
			case 5:
				if(level_5_max_score == 0) {
					level_5_max_score = level_5_current_score;
				}
				if(level_5_max_score < level_5_current_score) {
					level_5_max_score = level_5_current_score;
				}
				break;
			case 6:
				if(level_6_max_score == 0) {
					level_6_max_score = level_6_current_score;
				}
				if(level_6_max_score < level_6_current_score) {
					level_6_max_score = level_6_current_score;
				}
				break;
			case 7:
				if(level_7_max_score == 0) {
					level_7_max_score = level_7_current_score;
				}
				if(level_7_max_score < level_7_current_score) {
					level_7_max_score = level_7_current_score;
				}
				break;
		
			}
			
		}
	
	
	// getter for version display in level select state
	public String getVersion() {
		return version;
	}
	
//	public long getTotalScore() {
//		return total_score;
//	}
	
	public void addToScore(int i) {
		this.forever_score += i;
		
	}
	
	
	
	

	public void update() {
		try {
			gameStates[currentState].update();

		} catch (NullPointerException e) {
			//System.out.println("GameStateManager ln 108 update() NullPointerException");
			//e.printStackTrace();
		} catch(Exception e) {
			e.printStackTrace();
		}

	}

	public void draw(Graphics2D g) {
		try {
			gameStates[currentState].draw(g);
		} catch (Exception e) {
			//System.out.println("GameStateManager ln 121 draw() NullPointerException");

			//e.printStackTrace();
		}

	}

	public void keyPressed(int k) throws IOException {
		gameStates[currentState].keyPressed(k);
	}

	public void keyReleased(int k) {
		gameStates[currentState].keyReleased(k);
	}

}
