package GameState;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;

import TileMap.Background;

public class DisplayEnemyState extends GameState {

	private Background bg;

	private int currentChoice = 0;
	private String[] options = { "SandViper", "Spore", "Pancake", "Gorn" };
	//private Color titleColor;
	private Font titleFont;

	private Font font;
	
	public DisplayEnemyState(GameStateManager gsm) {
		this.gsm = gsm;
		
		try {

			bg = new Background("/Backgrounds/displayenemybackground.gif", 1);
			bg.setVector(0, 0);	//(-0.1, 0)

			//titleColor = new Color(128, 128, 128);
			titleFont = new Font("Courier New", Font.PLAIN, 22);
			font = new Font("Courier New", Font.PLAIN, 12);

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	
	@Override
	public void init() {
	
		
	}

	@Override
	public void update() {
		bg.update();
		
	}

	@Override
	public void draw(Graphics2D g) {
		// draw bg
				bg.draw(g);

				// draw title
				g.setColor(Color.WHITE);
				g.setFont(titleFont);
				g.drawString("ENEMIES", 120, 80);

				// draw menu
				g.setFont(font);
				for (int i = 0; i < options.length; i++) {
//					if (i == currentChoice) {
//						g.setColor(Color.WHITE);
//					} else {
//						g.setColor(Color.GRAY);
//					}
					g.drawString(options[i], 20 + (i * 82), 110 );
				}
				
				g.setColor(Color.WHITE);
				g.drawString("BACK ( ENTER )", 120, 220);
		
	}

	private void select() {
		if (currentChoice == 0) {
			// Start // Level Select
			gsm.setState(GameStateManager.MENUSTATE);	
		}

	}
	
	@Override
	public void keyPressed(int k) {
		if (k == KeyEvent.VK_ENTER) {
			select();
		}
		
	}

	@Override
	public void keyReleased(int k) {
		// TODO Auto-generated method stub
		
	}



}
