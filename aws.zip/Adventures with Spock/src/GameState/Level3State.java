// Level 1: Escape from Vulcan

package GameState;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import Audio.AudioPlayer;
import Entity.Collectable;
import Entity.Enemy;
import Entity.Explosion;
import Entity.HUD;
import Entity.HealthPack;
import Entity.PhaserUpgrade;
import Entity.Player;
import Entity.PowerUp;
import Entity.Star;

import Entity.Enemies.Gorn;
import Entity.Enemies.Pancake;
import Entity.Enemies.SandViper;
import Main.GamePanel;
import TileMap.*;

public class Level3State extends GameState {

	private TileMap tileMap;
	private Background bg;

	private Player player;
	// private Enemy boss;
	private boolean bossIsDead = false;

	private ArrayList<Enemy> enemies;
	private ArrayList<PowerUp> powerUps;
	private ArrayList<Collectable> collectables;
	private ArrayList<Explosion> explosions;

	private HUD hud;
	private HUD bossHud;
	private HUD timerHud;

	private AudioPlayer bgMusic;
	private AudioPlayer puSfx;
	private AudioPlayer cSfx;

	private int mc;

	
	//private long delay;
	//private long curr;

	public Level3State(GameStateManager gsm) {
		this.gsm = gsm;
		init();
	}

	// initializing tile map
	public void init() {
		
		// audio mute
		//this.mute = true;
		
		this.lock = false;

		// setting max collectables for level
		this.maxCollectables = 5;

		tileMap = new TileMap(30);
		tileMap.loadTiles("/Tilesets/vulcantiles_20.gif");
		tileMap.loadMap("/Maps/vulcan_20_mk2.map");
		tileMap.setPosition(0, 0);
		tileMap.setTween(.06); // 0.07

		bg = new Background("/Backgrounds/level1vulcan.gif", .015); // .015

		player = new Player(tileMap, gsm);
		player.setPosition(80, 250); // 70, 250

		populateEnemies();
		populatePowerUps();
		populateCollectables();

		explosions = new ArrayList<Explosion>();

		hud = new HUD(player);
		timerHud = new HUD(elapsed);
	

		bgMusic = this.level_music_level1;
		
		puSfx = new AudioPlayer("/SFX/spokvoice_find_2.mp3");
		cSfx = new AudioPlayer("/SFX/collectable_found.mp3");

		if(!this.getMute()) {
			bgMusic.play();
			mc = 0;
		}
		
		startTimer = System.nanoTime();
		
	}

	private void populateEnemies() {

		enemies = new ArrayList<Enemy>();
		SandViper sv;

		Point[] points = new Point[] { new Point(400, 220), new Point(310, 195), new Point(480, 195),
				new Point(540, 195), new Point(1080, 195), new Point(1730, 230), new Point(1770, 230),

				new Point(1900, 140), new Point(1800, 140), new Point(1850, 50), new Point(2200, 140),
				new Point(2500, 50), new Point(2400, 195), new Point(2600, 195), new Point(2800, 195),
				new Point(2950, 195)
//			new Point(2300, 200),
//			new Point(2500, 200),
//			new Point(2700, 200),
//			new Point(2850, 200),
		};

		SandViper ssv;
	
		Point[] sPoints = new Point[] { new Point(160, 195), new Point(330, 135), new Point(720, 45),
				new Point(900, 255), new Point(1260, 195), new Point(1580, 255),

				new Point(1900, 165), new Point(2070, 165), new Point(2300, 165), new Point(1900, 75),
				new Point(2050, 75), new Point(2500, 135), new Point(2625, 105), new Point(2800, 255)

		};

		Gorn gorn;
		Point[] gPoints = new Point[] { new Point(3000, 180) };

		Pancake pancake;
		Point[] pPoints = new Point[] { new Point(1200, 100), new Point(1500, 250), new Point(2200, 100) };

		// moving sandviper loop
		for (int i = 0; i < points.length; i++) {
			sv = new SandViper(tileMap, gsm);
			sv.setPosition(points[i].x, points[i].y);
			sv.setBoss(false);
			sv.setType(0);
			enemies.add(sv);
			//maxPossibleScore += sv.getScore();

		}

		// stationary sandviper loop
		for (int i = 0; i < sPoints.length; i++) {
			ssv = new SandViper(tileMap, gsm);
			ssv.setPosition(sPoints[i].x, sPoints[i].y);
			ssv.setBoss(false);
			ssv.setSpeed((double) 0);
			ssv.setType(1);
			enemies.add(ssv);
			//maxPossibleScore += ssv.getScore();

		}

		// pancake horizontal
		for (int i = 0; i < pPoints.length; i++) {
			pancake = new Pancake(tileMap, gsm);
			pancake.setPosition(pPoints[i].x, pPoints[i].y);
			pancake.setBoss(false);
			pancake.setType(0); // horizontal = 0
			enemies.add(pancake);
			//maxPossibleScore += pancake.getScore();
		}

		// gorn loop
		for (int i = 0; i < gPoints.length; i++) {
			gorn = new Gorn(tileMap, gsm, player);
			gorn.setPosition(gPoints[i].x, gPoints[i].y);
			gorn.setBoss(true);
			gorn.setMaxHealth(30); // this is the default, just to remind myself here is where and how much to
									// vary.	
			bossHud = new HUD(gorn);
			
			enemies.add(gorn);
			//maxPossibleScore += gorn.getScore();

		}

	}

	private void populatePowerUps() {
		powerUps = new ArrayList<PowerUp>();
		HealthPack hp;
		PhaserUpgrade pu;
//		UpgradeJump j;

		// healthpack spawn
		Point[] hPoints = new Point[] { new Point(1335, 50)

		};

		// phaserpack spawn
		Point[] pPoints = new Point[] { new Point(460, 105) };



		// health pack specs
		for (int i = 0; i < hPoints.length; i++) {
			hp = new HealthPack(tileMap, gsm);
			hp.setPosition(hPoints[i].x, hPoints[i].y);
			hp.setMovement(false);
			hp.setMultiplier(1.5);
			hp.setType(0); // sending 0 for health effects, 1 for phaser effects
			powerUps.add(hp);
			//maxPossibleScore += hp.getScore();

		}

		// phaser pack specs
		for (int i = 0; i < pPoints.length; i++) {
			pu = new PhaserUpgrade(tileMap, gsm);
			pu.setPosition(pPoints[i].x, pPoints[i].y);
			pu.setMovement(false);
			pu.setMultiplier(1.5);
			pu.setType(1); // sending 0 for health effects, 1 for phaser effects
			powerUps.add(pu);
			//maxPossibleScore += pu.getScore();

		}

	}

	// populating collectables
	private void populateCollectables() {
		collectables = new ArrayList<Collectable>();
		Star s;

		Point[] starPoints = new Point[] { new Point(50, 30), new Point(600, 50), new Point(2800, 70),
				new Point(1600, 30), new Point(2300, 80) };

		for (int i = 0; i < starPoints.length; i++) {
			s = new Star(tileMap, gsm);
			s.setPosition(starPoints[i].x, starPoints[i].y);
			s.setMovement(false);
			s.setEffect(0);
			s.setType(0); // 0 for stars....
			collectables.add(s);
			//maxPossibleScore += s.getScore();

		}

	}
	
	public long getElapsed() { return elapsed; }
	
	

	public void update() {

		if(!this.getMute()) {
			// audio update
			mc++;
			if (mc >= 375) {
				bgMusic.play();
				mc = 0;
			}
		}

		
		// for timer
		this.elapsed = ( System.nanoTime() - startTimer) / 1000000;
		this.currentScore = gsm.level_1_current_score;
		
		// check quit
		if (player.getQuit()) {
			bgMusic.stop();
			gsm.setState(4); // (4) levelselectstate (0) main menu
		}

		// update player
		player.update();

		tileMap.setPosition(GamePanel.WIDTH / 2 - player.getx(), GamePanel.HEIGHT / 2 - player.gety());

		// set background
		bg.setPosition(tileMap.getx(), tileMap.gety());

		// attack enemies
		player.checkAttack(enemies, powerUps, collectables);
		// player.checkAttack(powerUps);
		if (player.checkDead()) {
			bgMusic.stop();
			gsm.setState(3); // GAMEOVERSTATE

		}

		if (player.getx() >= 3160 && player.getx() <= 3180 && player.gety() > 220) {
			// spokvictorySfx.play();
			if (bossIsDead) {
				
				//	calculating final time for the level in here
				gsm.level_1_current_score += 1000;
				gsm.forever_score += 1000;
				
				// telling GameState the final time to display on level complete screen.
				finalTime = getElapsed();
				gsm.level_1_time = finalTime;
	
				bgMusic.stop();
				gsm.setState(5);
			}

		}

		// update all enemies
		for (int i = 0; i < enemies.size(); i++) {
			Enemy e = enemies.get(i);
			e.update(gsm);
			if (e.isDead()) {
				gsm.level_1_current_score += e.getScore();
				gsm.forever_score += e.getScore();
				if (e.isBoss()) {
					bossIsDead = true;
				}
				enemies.remove(i);

				i--;
				explosions.add(new Explosion(e.getx(), e.gety()));

			}

		}

		// update all powerUps
		for (int i = 0; i < powerUps.size(); i++) {
			PowerUp ph = powerUps.get(i);
			ph.update(gsm);
			if (ph.isUsed()) {
				gsm.level_1_current_score += ph.getScore();
				gsm.forever_score += ph.getScore();
				puSfx.play();
				powerUps.remove(i);
				i--;
				// could add powerUp animation here for when player gets it... #todo...
				// could alter gamestate here if you wanted....scary thots

			}
		}

		// update all collectables
		for (int i = 0; i < collectables.size(); i++) {
			Collectable c = collectables.get(i);
			c.update(gsm);
			if (c.isUsed()) {
				cSfx.play();
				gsm.level_1_current_score += c.getScore();
				gsm.forever_score += c.getScore();
				if (player.getCollectablesFound() >= maxCollectables) {
					
					bgMusic.stop();
					
					gsm.level_1_current_score += 750;
					gsm.forever_score += 750;
					finalTime = getElapsed();
					gsm.level_1_time = finalTime;
					gsm.setState(5); // to LEVELCOMPLETESTATE
				}

				collectables.remove(i);
				i--;

			}
		}

		// update all explosions
		for (int i = 0; i < explosions.size(); i++) {
			explosions.get(i).update();
			if (explosions.get(i).shouldRemove()) {
				explosions.remove(i);
				i--;
			}
		}

	}

	public void draw(Graphics2D g) {
		// draw background
		bg.draw(g);

		// draw tileMap
		tileMap.draw(g);

		// draw player
		player.draw(g);

		// draw enemies
		for (int i = 0; i < enemies.size(); i++) {
			
			enemies.get(i).draw(g);
		}

		// draw power ups
		for (int i = 0; i < powerUps.size(); i++) {
			powerUps.get(i).draw(g);
		}

		// draw collectables
		for (int i = 0; i < collectables.size(); i++) {
			collectables.get(i).draw(g);
		}

		// draw explosions
		for (int i = 0; i < explosions.size(); i++) {
			explosions.get(i).setMapPosition((int) tileMap.getx(), (int) tileMap.gety());
			explosions.get(i).draw(g);
		}

		// draw HUD
		hud.draw(this, g, 0); // sending 0 for player
		if (player.getx() >= 2850) {
			bossHud.draw(this, g, 1); // sending 1 for Boss
		}
		timerHud.draw(this,  g,  2);

	}

	// input
	public void keyPressed(int k) {

		if (k == KeyEvent.VK_LEFT) {
			player.setLeft(true);
		}
		if (k == KeyEvent.VK_RIGHT) {
			player.setRight(true);
		}
		if (k == KeyEvent.VK_UP) {
			player.setUp(true);
		}
		if (k == KeyEvent.VK_DOWN) {
			player.setDown(true);
		}
		if (k == KeyEvent.VK_SPACE) {
			player.setJumping(true);
		}
		if (k == KeyEvent.VK_SHIFT) {
			player.setGliding(true);
		}
		if (k == KeyEvent.VK_S) {
			player.setGripping(true);
		}
		if (k == KeyEvent.VK_F) {
			player.setShooting(true);
		}

		if (k == KeyEvent.VK_P) {
			bgMusic.stop();
			player.setQuit(true);
		}

	}
		

	public void keyReleased(int k) {

		if (k == KeyEvent.VK_LEFT) {
			player.setLeft(false);
		}
		if (k == KeyEvent.VK_RIGHT) {
			player.setRight(false);
		}
		if (k == KeyEvent.VK_UP) {
			player.setUp(false);
		}
		if (k == KeyEvent.VK_DOWN) {
			player.setDown(false);
		}
		if (k == KeyEvent.VK_SPACE) {
			player.setJumping(false);
		}
		if (k == KeyEvent.VK_SHIFT) {
			player.setGliding(false);
		}
		if (k == KeyEvent.VK_S) {
			player.setGripping(false);
		}
		if (k == KeyEvent.VK_F) {
			player.setShooting(false);
		}



	}

}
