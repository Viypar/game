package GameState;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.io.IOException;

import Audio.AudioPlayer;
import TileMap.Background;

public class LevelCompleteState extends GameState{

	private Background bg;

	private int currentChoice = 0;
	private int prevGameStateInt;
	private long prevTime;
	private long bestTime;
	private long prevScore;
	private long bestScore;
	private String[] options = { "Continue", "Save and Exit" };
	private Color titleColor;
	private Font titleFont;
	private AudioPlayer victory;
	
	private Save s;
	
	private Font font;
	private Font timeFont;
	
	private AudioPlayer up_sound = new AudioPlayer("/SFX/up_menu_sound.mp3");
	private AudioPlayer down_sound = new AudioPlayer("/SFX/down_menu_sound.mp3");
	private AudioPlayer select_sound = new AudioPlayer("/SFX/select_menu_sound.mp3");

	public LevelCompleteState(GameStateManager gsm, int prevStateInt) {
		this.prevGameStateInt = prevStateInt;
		//System.out.println("in LevelCompleteState, prevStateInt = " + prevStateInt);
		// audio
		victory = new AudioPlayer("/SFX/spokvoice_victory_2.mp3");
		//play audio
		victory.play();
		this.gsm = gsm;
		

		try {

			bg = new Background("/Backgrounds/awstitlebackground.gif", 1);
			bg.setVector(-.3, 0);	//(-0.1, 0)

			titleColor = new Color(128, 128, 128);
			titleFont = new Font("Lucida Sans", Font.PLAIN, 24);
			timeFont = new Font("Lucida Sans", Font.PLAIN, 16);
			font = new Font("Lucida Sans", Font.PLAIN, 16);

			switch(prevGameStateInt) {
			case 11:
				gsm.calculateBestTime(1);
				prevTime = gsm.level_1_time;
				bestTime = gsm.level_1_best;
				
				gsm.calculateBestScore(1);
				prevScore = gsm.level_1_current_score;
				gsm.level_1_current_score = 0;
				bestScore = gsm.level_1_max_score;
				//System.out.println("displayTime = " + displayTime);
				break;
				
			case 12:
				gsm.calculateBestTime(2);
				prevTime = gsm.level_2_time;
				bestTime = gsm.level_2_best;
				
				gsm.calculateBestScore(2);
				prevScore = gsm.level_2_current_score;
				gsm.level_2_current_score = 0;
				bestScore = gsm.level_2_max_score;
				break;
				
			case 13:
				gsm.calculateBestTime(3);
				prevTime = gsm.level_3_time;
				bestTime = gsm.level_3_best;
				
				gsm.calculateBestScore(3);
				prevScore = gsm.level_3_current_score;
				gsm.level_3_current_score = 0;
				bestScore = gsm.level_3_max_score;
				break;
				
			case 14:
				gsm.calculateBestTime(4);
				prevTime = gsm.level_4_time;
				bestTime = gsm.level_4_best;
				
				gsm.calculateBestScore(4);
				prevScore = gsm.level_4_current_score;
				gsm.level_4_current_score = 0;
				bestScore = gsm.level_4_max_score;
				break;
				
			case 15:
				gsm.calculateBestTime(5);
				prevTime = gsm.level_5_time;
				bestTime = gsm.level_5_best;
				
				gsm.calculateBestScore(5);
				prevScore = gsm.level_5_current_score;
				gsm.level_5_current_score = 0;
				bestScore = gsm.level_5_max_score;
				break;
				
			case 16:
				gsm.calculateBestTime(6);
				prevTime = gsm.level_6_time;
				bestTime = gsm.level_6_best;
				
				gsm.calculateBestScore(6);
				prevScore = gsm.level_6_current_score;
				gsm.level_6_current_score = 0;
				bestScore = gsm.level_6_max_score;
				break;
				
			case 17:
				gsm.calculateBestTime(7);
				prevTime = gsm.level_7_time;
				bestTime = gsm.level_7_best;
				
				gsm.calculateBestScore(7);
				prevScore = gsm.level_7_current_score;
				gsm.level_7_current_score = 0;
				bestScore = gsm.level_7_max_score;
				break;
	
				
			}
			
		
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void init() {
		
	}

	public void update() {
		bg.update();
	}

	public void draw(Graphics2D g) {

		
		
		// draw bg
		bg.draw(g);
		

		
		// draw title
		g.setColor(titleColor);
		g.setFont(titleFont);
		g.drawString("LEVEL COMPLETE!", 70, 50);
		
		
		g.setFont(timeFont);
		g.drawString("Time: " + prevTime / 1000, 60, 100);
		g.drawString("Record: " + bestTime / 1000, 180, 100);
		g.drawString("Score: " + prevScore, 60, 140);
		g.drawString("Record: " + bestScore, 180, 140);

		// draw menu
		g.setFont(font);
		for (int i = 0; i < options.length; i++) {
			if (i == currentChoice) {
				g.setColor(Color.WHITE);
			} else {
				g.setColor(Color.GRAY);
			}
			g.drawString(options[i], 80 + i * 100, 200);
		}
		
	}

	private void select() {
	
		if(currentChoice == 0) {
			gsm.setState(GameStateManager.LEVELSELECTSTATE);
		}
		
		
		if (currentChoice == 1) {
			// Level Select Menu
			try {
				s = new Save(gsm);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.exit(0);
		}
		
	}

	public void keyPressed(int k) {
		if (k == KeyEvent.VK_ENTER) {
			select_sound.play();
			select();
		}
		if (k == KeyEvent.VK_LEFT) {
			up_sound.play();
			currentChoice--;
			if( currentChoice == -1) {
				currentChoice = options.length-1;
			}
		}
		if(k == KeyEvent.VK_RIGHT ){
			down_sound.play();
			currentChoice++;
			if(currentChoice == options.length) {
				currentChoice = 0;
			}
		}

	}

	public void keyReleased(int k) {
	}

	
	
}
