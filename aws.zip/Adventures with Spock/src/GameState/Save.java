package GameState;



import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

import GameState.GameState;
import GameState.GameStateManager;

import java.io.IOException;
import java.io.OutputStream;



public class Save{

	private String absolutePath;
	//public String pathName = "C:\\Users\\Pwatk\\Nextcloud\\Jacob and I Projects\\Adventures with Spok\\Install\\gamesave.txt";
	//private String pathName = "C:\\Users\\swdru\\2d_sidescroll_game\\Adventures with Spock\\gamesave.txt";
	//private String pathName = "%appdata%\\Adventures with Spock\\gamesave.txt";
	//private String pathName = "/Saves/gamesave.txt";
	//private String pathName = "C:\\Users\\gdhen\\java stuff\\GAME VERSIONS\\gamesave.txt";
	private String pathName = "C:\\Users\\Public\\Adventures with Spock\\gamesave.txt";
	
	
	private GameStateManager gsm;
	public boolean success;
	
	// constructor
	public Save(GameStateManager gsm) throws IOException {
		this.gsm = gsm;
		
		//public static final File savedir = new File(new File(System.getProperty("user.home")), ".yourgame");
		//FileReader fr = new FileReader(new File(savedir, "level.txt"));
		
		
		writeFile();	//works
	
		
	}
	
	// writing new file
	public void writeFile() throws IOException {
		
//		FileWriter write = new FileWriter("/Saves/save_test.txt");
//		PrintWriter print_line = new PrintWriter(write);
//		print_line.printf(" %d", gsm.level_1_best);
		
		try {
			
			
			File file = new File(pathName);
			if(file.createNewFile()) {
				//System.out.println("File created: " + file.getName());
				//System.out.println("Absolute path: " + file.getAbsolutePath());
			}
			//gsm.times_played++;
			FileWriter fw = new FileWriter(file);
			fw.write(Long.toString(gsm.times_played));
			fw.write("\n");
			fw.write(Long.toString(gsm.forever_score));
			fw.write("\n");
			fw.write(Long.toString(gsm.level_1_max_score));
			fw.write("\n");
			fw.write(Long.toString(gsm.level_2_max_score));
			fw.write("\n");
			fw.write(Long.toString(gsm.level_3_max_score));
			fw.write("\n");
			fw.write(Long.toString(gsm.level_4_max_score));
			fw.write("\n");
			fw.write(Long.toString(gsm.level_5_max_score));
			fw.write("\n");
			fw.write(Long.toString(gsm.level_6_max_score));
			fw.write("\n");
			fw.write(Long.toString(gsm.level_7_max_score));
			fw.write("\n");
			fw.write(Long.toString(gsm.level_1_best));
			fw.write("\n");
			fw.write(Long.toString(gsm.level_2_best));
			fw.write("\n");
			fw.write(Long.toString(gsm.level_3_best));
			fw.write("\n");
			fw.write(Long.toString(gsm.level_4_best));
			fw.write("\n");
			fw.write(Long.toString(gsm.level_5_best));
			fw.write("\n");
			fw.write(Long.toString(gsm.level_6_best));
			fw.write("\n");
			fw.write( Long.toString(gsm.level_7_best) );
			fw.write("\n");
			
			fw.close();
				
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
		
		
	}
	
	

	
	
	
	
	
	
	

	
	
}
