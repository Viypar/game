package GameState;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import Audio.AudioPlayer;
import Entity.Collectable;
import Entity.Enemy;
import Entity.Explosion;
import Entity.HUD;
import Entity.HealthPack;
import Entity.PhaserUpgrade;
import Entity.Player;
import Entity.PowerUp;
import Entity.Star;
import Entity.Enemies.Gorn;
import Entity.Enemies.Pancake;
import Entity.Enemies.Spore;
import Entity.Enemies.Vampire;
import Main.GamePanel;
import TileMap.Background;
import TileMap.TileMap;

public class LevelNoReturnState extends GameState {

	
	private TileMap tileMap;
	private Background bg;

	private Player player;
	// private Enemy boss;
	private boolean bossIsDead = false;

	private ArrayList<Enemy> enemies;
	private ArrayList<PowerUp> powerUps;
	private ArrayList<Collectable> collectables;
	private ArrayList<Explosion> explosions;

	private HUD hud;
	private HUD bossHud;
	private HUD timerHud;

	private AudioPlayer bgMusic;
	private AudioPlayer puSfx;
	private AudioPlayer cSfx;

	private int mc;

	//private long delay;
	//private long curr;

	
	
	public LevelNoReturnState(GameStateManager gsm) {
		this.gsm = gsm;
		init();
	}
	
	@Override
	public void init() {
	
		// audio mute
		//this.mute = true;
		
		// setting max collectables for level
				this.maxCollectables = 5;

				tileMap = new TileMap(30);
				tileMap.loadTiles("/Tilesets/vulcantiles.gif");
				tileMap.loadMap("/Maps/noreturn_long.map");
				tileMap.setPosition(0, 0);
				tileMap.setTween(.06); // 0.07

				bg = new Background("/Backgrounds/noreturn_background.gif", .015); // .015

				player = new Player(tileMap, gsm);
				player.setPosition(50, 230); // 70, 250
				player.setJumpStart(-5.1);

				populateEnemies();
				populatePowerUps();
				populateCollectables();

				explosions = new ArrayList<Explosion>();

				hud = new HUD(player);
				// bossHud = new HUD();
				timerHud = new HUD(elapsed);

				bgMusic = this.level_music_danger1;
				puSfx = new AudioPlayer("/SFX/spokvoice_find_2.mp3");
				cSfx = new AudioPlayer("/SFX/collectable_found.mp3");

				if(!this.getMute()) {
					bgMusic.play();
					mc = 0;
				}
				
				startTimer = System.nanoTime();
				
		
	}
	
	private void populateEnemies() {

		enemies = new ArrayList<Enemy>();

		Spore spore;
		Point[] sporePoints = new Point[] { 
			new Point(370, 200),
			new Point(500, 180),
			new Point(615, 200),
			new Point(780, 200),
			new Point(930, 200),
			new Point(1120, 200),
			new Point(1360, 200),
			new Point(1510, 200),
			new Point(1750, 200),
			new Point(2160, 200),
			new Point(2380, 200),
			new Point(2600, 200),
			new Point(2715, 180)

		};
		
		Pancake pch;
		Point[] phPoints = new Point[] { 
				
				new Point(600, 80),
				new Point(1000, 100),
				new Point(800, 200),
				new Point(1300, 80),
	//			new Point(1500, 200),
				new Point(1800, 80),
				new Point(2200, 100),
				new Point(2900, 80),
	//			new Point(3100, 100),
				new Point(3300, 200),
				new Point(3600, 200),
				new Point(3600, 140),
				new Point(3700, 80),
				new Point(3900, 100),
				new Point(3900, 200),
				new Point(4500, 140),
				new Point(4800, 60),
	//			new Point(5000, 80),
//				new Point(300, 300), new Point(100, 400), new Point(200, 500), new Point(600, 700), new Point(200, 700),
//				new Point(400, 930), new Point(400, 1100), new Point(400, 1210), new Point(600, 1210),
//				new Point(200, 1330), new Point(580, 1340), new Point(400, 1620), new Point(300, 1920),
//				new Point(700, 2050), new Point(700, 2010), new Point(100, 2200), new Point(100, 2350),
//				new Point(400, 2450), new Point(600, 2550), new Point(700, 2600) 
				};
		
		Gorn gorn;
		Point[] gPoints = new Point[] {
//			//new Point(5460, 210),
				new Point(3210, 140),
				new Point(3780, 200),
				new Point(4400, 200),
				new Point(4770, 200)

		};
		
		Vampire v;
		Point[] vPoints = new Point[] { new Point(5400, 180) };

		// spore
		for (int i = 0; i < sporePoints.length; i++) {
			spore = new Spore(tileMap, gsm, player);
			spore.setPosition(sporePoints[i].getX(), sporePoints[i].y);
			spore.setBoss(false);
			spore.setShootFreq(12000);
			enemies.add(spore);

		}
		
		// for pancakes horizontal
				for (int i = 0; i < phPoints.length; i++) {
					pch = new Pancake(tileMap, gsm);
					pch.setPosition(phPoints[i].x, phPoints[i].y);
					pch.setType(0); // 0 for moving horizontally
					enemies.add(pch);
				}

		// gorn
		for (int i = 0; i < gPoints.length; i++) {
			gorn = new Gorn(tileMap, gsm, player);
			gorn.setPosition(gPoints[i].x, gPoints[i].y);
			gorn.setBoss(false);
			gorn.setMaxHealth(20);
			if (gorn.isBoss()) {
				bossHud = new HUD(gorn);
			}
			enemies.add(gorn);
		}
		
		// vampire loop
				for (int i = 0; i < vPoints.length; i++) {
					v = new Vampire(tileMap, gsm, player);
					v.setPosition(vPoints[i].x, vPoints[i].y);
					v.setBoss(true);
					v.setMaxHealth(50); // this is the default, just to remind myself here is where and how much to
										// vary.
					if (v.isBoss()) {
						bossHud = new HUD(v);
					}
					// gorn.setSpeed((double) 0);
					// gorn.setType(1);
					enemies.add(v);

				}

	}

	// populating power ups
	private void populatePowerUps() {
		powerUps = new ArrayList<PowerUp>();
		HealthPack hp;
		PhaserUpgrade pu;

		Point[] hPoints = new Point[] { new Point(4700, 220)

		};

		Point[] pPoints = new Point[] { new Point(1510, 220) };

		for (int i = 0; i < hPoints.length; i++) {
			hp = new HealthPack(tileMap, gsm);
			hp.setPosition(hPoints[i].x, hPoints[i].y);
			hp.setMovement(false);
			hp.setMultiplier(2);
			hp.setType(0); // sending 0 for health effects, 1 for phaser effects
			powerUps.add(hp);

		}

		for (int i = 0; i < pPoints.length; i++) {
			pu = new PhaserUpgrade(tileMap, gsm);
			pu.setPosition(pPoints[i].x, pPoints[i].y);
			pu.setMovement(false);
			pu.setMultiplier(1.5);
			pu.setType(1); // sending 0 for health effects, 1 for phaser effects
			powerUps.add(pu);

		}

	}

	// populating collectables
	private void populateCollectables() {
		collectables = new ArrayList<Collectable>();
		Star s;

		Point[] starPoints = new Point[] {
				 new Point(5900, 200),
				new Point(4500, 200),
				new Point(1690, 200), new Point(3800, 120), new Point(990, 50) };

		for (int i = 0; i < starPoints.length; i++) {
			s = new Star(tileMap, gsm);
			s.setPosition(starPoints[i].x, starPoints[i].y);
			s.setMovement(false);
			s.setEffect(0);
			s.setType(0); // 0 for stars....
			collectables.add(s);

		}

	}
	
	

	@Override
	public void update() {
		
		this.elapsed = (System.nanoTime() - startTimer) / 1000000;
		this.currentScore = gsm.level_7_current_score;
		
		// audio update
		if(!this.getMute()) {
			mc++;
			if (mc >= 375) {
				bgMusic.play();
				mc = 0;
			}
		}
	
		
				// check quit
				if (player.getQuit()) {
					bgMusic.stop();
					gsm.setState(4); // (4) levelselectstate (0) main menu
				}

				// update player
				player.update();

				tileMap.setPosition(GamePanel.WIDTH / 2 - player.getx(), GamePanel.HEIGHT / 2 - player.gety());

				// set background
				bg.setPosition(tileMap.getx(), tileMap.gety());

				// attack enemies
				player.checkAttack(enemies, powerUps, collectables);
				// player.checkAttack(powerUps);
				if (player.checkDead()) {
					bgMusic.stop();
					gsm.setState(3); // GAMEOVERSTATE

				}

				if (player.getx() >= 5530 && player.getx() <= 5560 && player.gety() > 220) {
					// spokvictorySfx.play();
					if (bossIsDead) {
						
						finalTime = getElapsed();
						gsm.level_7_time = finalTime;
						gsm.level_7_current_score += 1000;
						gsm.forever_score += 1000;
						bgMusic.stop();
						gsm.setState(5);
					}

				}

				// update all enemies
				for (int i = 0; i < enemies.size(); i++) {
					Enemy e = enemies.get(i);
					e.update(gsm);
					if (e.isDead()) {
						gsm.level_7_current_score += e.getScore();
						gsm.forever_score += e.getScore();
						if (e.isBoss()) {
							bossIsDead = true;
						}
						enemies.remove(i);

						i--;
						explosions.add(new Explosion(e.getx(), e.gety()));

					}

				}

				// update all powerUps
				for (int i = 0; i < powerUps.size(); i++) {
					PowerUp ph = powerUps.get(i);
					ph.update(gsm);
					if (ph.isUsed()) {
						puSfx.play();
						gsm.level_7_current_score += ph.getScore();
						gsm.forever_score += ph.getScore();
						powerUps.remove(i);
						i--;
						// could add powerUp animation here for when player gets it... #todo...
						// could alter gamestate here if you wanted....scary thots

					}
				}

				// update all collectables
				for (int i = 0; i < collectables.size(); i++) {
					Collectable c = collectables.get(i);
					c.update(gsm);
					if (c.isUsed()) {
						cSfx.play();
						gsm.level_7_current_score += c.getScore();
						gsm.forever_score += c.getScore();
						if (player.getCollectablesFound() >= maxCollectables) {
							gsm.level_7_current_score += 750;
							gsm.forever_score += 750;
							finalTime = getElapsed();
							gsm.level_7_time = finalTime;
							bgMusic.stop();
							gsm.setState(5); // to LEVELCOMPLETESTATE
						}

						collectables.remove(i);
						i--;

					}
				}

				// update all explosions
				for (int i = 0; i < explosions.size(); i++) {
					explosions.get(i).update();
					if (explosions.get(i).shouldRemove()) {
						explosions.remove(i);
						i--;
					}
				}
		
	}

	@Override
	public void draw(Graphics2D g) {
		// draw background
				bg.draw(g);

				// draw tileMap
				tileMap.draw(g);

				// draw player
				player.draw(g);

				// draw enemies
				for (int i = 0; i < enemies.size(); i++) {
					enemies.get(i).draw(g);
				}

				// draw power ups
				for (int i = 0; i < powerUps.size(); i++) {
					powerUps.get(i).draw(g);
				}

				// draw collectables
				for (int i = 0; i < collectables.size(); i++) {
					collectables.get(i).draw(g);
				}

				// draw explosions
				for (int i = 0; i < explosions.size(); i++) {
					explosions.get(i).setMapPosition((int) tileMap.getx(), (int) tileMap.gety());
					explosions.get(i).draw(g);
				}

				// draw HUD
				hud.draw(this, g, 0); // sending 0 for player
				if (player.getx() >= 5150) {
					bossHud.draw(this, g, 1); // sending 1 for Boss
				}
				timerHud.draw(this, g, 2);
		
	}

	@Override
	public void keyPressed(int k) {
		if (k == KeyEvent.VK_LEFT) {
			player.setLeft(true);
		}
		if (k == KeyEvent.VK_RIGHT) {
			player.setRight(true);
		}
		if (k == KeyEvent.VK_UP) {
			player.setUp(true);
		}
		if (k == KeyEvent.VK_DOWN) {
			player.setDown(true);
		}
		if (k == KeyEvent.VK_SPACE) {
			player.setJumping(true);
		}
		if (k == KeyEvent.VK_SHIFT) {
			player.setGliding(true);
		}
		if (k == KeyEvent.VK_S) {
			player.setGripping(true);
		}
		if (k == KeyEvent.VK_F) {
			player.setShooting(true);
		}

		if (k == KeyEvent.VK_P) {
			bgMusic.stop();
			player.setQuit(true);
		}

		
	}

	@Override
	public void keyReleased(int k) {
		if (k == KeyEvent.VK_LEFT) {
			player.setLeft(false);
		}
		if (k == KeyEvent.VK_RIGHT) {
			player.setRight(false);
		}
		if (k == KeyEvent.VK_UP) {
			player.setUp(false);
		}
		if (k == KeyEvent.VK_DOWN) {
			player.setDown(false);
		}
		if (k == KeyEvent.VK_SPACE) {
			player.setJumping(false);
		}
		if (k == KeyEvent.VK_SHIFT) {
			player.setGliding(false);
		}
		if (k == KeyEvent.VK_S) {
			player.setGripping(false);
		}
		if (k == KeyEvent.VK_F) {
			player.setShooting(false);
		}

		
	}

}
