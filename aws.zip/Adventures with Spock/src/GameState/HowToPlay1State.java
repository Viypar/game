package GameState;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;

import TileMap.Background;

public class HowToPlay1State extends GameState{

	private Background bg;

	private int currentChoice = 0;
	private String[] options = { "Back", "Next" };
	//private Color titleColor;
	private Font titleFont;

	private Font font;
	
	
	public HowToPlay1State(GameStateManager gsm) {
		this.gsm = gsm;

		try {

			bg = new Background("/Backgrounds/movement_menu.gif", 1);
			bg.setVector(0, 0); // (-0.1, 0)

			//titleColor = new Color(128, 128, 128);
			titleFont = new Font("Courier New", Font.PLAIN, 20);
			font = new Font("Courier New", Font.PLAIN, 12);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	@Override
	public void init() {
		
		
	}

	@Override
	public void update() {
		bg.update();
		
	}
	
	@Override
	public void draw(Graphics2D g) {
		// draw bg
		bg.draw(g);

		// draw title
		g.setColor(Color.WHITE);
		g.setFont(titleFont);
		g.drawString("Movement", 120, 80);
		g.setFont(font);
		g.drawString("Left/Right", 30, 110);
		g.drawString("Jumping", 140, 110);
		g.drawString("Gliding", 230, 110);
		g.drawString(" <- ->", 40, 190);
		g.drawString("SPACE", 140, 190);
		g.drawString("Hold LSHIFT", 220, 190);

		// draw menu
		g.setFont(font);
		for (int i = 0; i < options.length; i++) {
			if (i == currentChoice) {
				g.setColor(Color.WHITE);
			} else {
				g.setColor(Color.GRAY);
			}
			g.drawString(options[i], 120 + i * 60, 220);
		}
		
	}

	private void select() {
		if (currentChoice == 0) {
			// Start // Level Select
			gsm.setState(GameStateManager.MENUSTATE); // add level choosing screen
		}
		if (currentChoice == 1) {
			// Help
			gsm.setState(GameStateManager.HOWTOPLAY2STATE);
		}

	}
	
	@Override
	public void keyPressed(int k) {
		if (k == KeyEvent.VK_ENTER) {
			select_sound.play();
			select();
		}
		if (k == KeyEvent.VK_LEFT) {
			down_sound.play();
			currentChoice--;
			if (currentChoice == -1) {
				currentChoice = options.length - 1;
			}
		}
		if (k == KeyEvent.VK_RIGHT) {
			up_sound.play();
			currentChoice++;
			if (currentChoice == options.length) {
				currentChoice = 0;
			}
		}
		
	}

	@Override
	public void keyReleased(int k) {
		// TODO Auto-generated method stub
		
	}


	
	

}
