package GameState;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import Audio.AudioPlayer;
import Entity.Collectable;
import Entity.Enemy;
import Entity.Explosion;
import Entity.HUD;
import Entity.HealthPack;
import Entity.PhaserUpgrade;
import Entity.Player;
import Entity.PowerUp;
import Entity.Star;
import Entity.Enemies.Gorn;
import Entity.Enemies.SandViper;
import Main.GamePanel;
import TileMap.*;

public class Level4State extends GameState {

	private TileMap tileMap;
	private Background bg;

	private Player player;
	private boolean bossIsDead = false;

	private ArrayList<Enemy> enemies;
	private ArrayList<PowerUp> powerUps;
	private ArrayList<Collectable> collectables;
	private ArrayList<Explosion> explosions;

	private HUD hud;
	private HUD bossHud;
	private HUD timerHud;

	private AudioPlayer bgMusic;
	public int mc;
	private AudioPlayer puSfx;
	private AudioPlayer cSfx;

	public Level4State(GameStateManager gsm) {

		this.gsm = gsm;
		init();
	}

	// initializing tile map
	public void init() {

		// audio mute
		//this.mute = true;
		
		// setting max collectables for level
		this.maxCollectables = 7;

		tileMap = new TileMap(30);
		tileMap.loadTiles("/Tilesets/level2-2.gif");
		tileMap.loadMap("/Maps/level4-1.map");
		tileMap.setPosition(0, 0);
		tileMap.setTween(.04); // 1.0

		bg = new Background("/Backgrounds/level2_320_gammavega.gif", 0.1); // .1

		player = new Player(tileMap, gsm);
		player.setPosition(80, 200);

		populateEnemies();
		populatePowerUps();
		populateCollectables();

		explosions = new ArrayList<Explosion>();

		hud = new HUD(player);
		timerHud = new HUD(elapsed);

		bgMusic = this.level_music_level2;
		puSfx = new AudioPlayer("/SFX/spokvoice_find_2.mp3");
		cSfx = new AudioPlayer("/SFX/collectable_found.mp3");
		
		if(!this.getMute()) {
			bgMusic.play();
			mc = 0;
		}
		
		startTimer = System.nanoTime();
		
	}

	private void populateEnemies() {

		enemies = new ArrayList<Enemy>();
		SandViper sv; // moving
		SandViper ssv; // stationary

		Point[] points = new Point[] { // map x total = 6,000 && y total = 270
				new Point(330, 210), new Point(450, 210), new Point(600, 210), new Point(750, 210),
				new Point(1200, 210), new Point(1380, 210), new Point(1650, 210), new Point(1680, 210),
				new Point(1710, 210), new Point(1760, 210), new Point(2010, 210), new Point(2190, 210),
				new Point(2400, 210), new Point(2550, 210), new Point(3270, 210), new Point(3750, 210),
				new Point(4110, 210), new Point(4560, 210), new Point(5070, 210), new Point(5040, 120),
				new Point(2360, 120)

		};

		Point[] sPoints = new Point[] {
				// new Point(330, 210),
				new Point(360, 105), new Point(705, 105), new Point(945, 195), new Point(1080, 105),
				new Point(1440, 105), new Point(1740, 105), new Point(2880, 165), new Point(3190, 135),
				new Point(2100, 225), new Point(3450, 75), new Point(3840, 75), new Point(4620, 45),
				new Point(4890, 135), new Point(5250, 45)

		};

		Gorn gorn;
		Point[] gPoints = new Point[] {
				// new Point(5460, 210),
				new Point(5640, 210)

		};

		// moving sandvipers
		for (int i = 0; i < points.length; i++) {
			sv = new SandViper(tileMap, gsm);
			sv.setPosition(points[i].x, points[i].y);
			sv.setBoss(false);
			sv.setType(0);
			enemies.add(sv);
		}

		// stationary sandvipers

		for (int i = 0; i < sPoints.length; i++) {
			ssv = new SandViper(tileMap, gsm);
			ssv.setPosition(sPoints[i].x, sPoints[i].y);
			ssv.setBoss(false);
			ssv.setSpeed((double) 0);
			ssv.setType(1); // pass 0 for moving, 1 for stationary
			enemies.add(ssv);
		}

		for (int i = 0; i < gPoints.length; i++) {
			gorn = new Gorn(tileMap, gsm, player);
			gorn.setPosition(gPoints[i].x, gPoints[i].y);
			gorn.setBoss(true);
			gorn.setMaxHealth(35);
			if (gorn.isBoss()) {
				bossHud = new HUD(gorn);
			}
			enemies.add(gorn);
		}

	}

	// populating power ups
	private void populatePowerUps() {
		powerUps = new ArrayList<PowerUp>();
		HealthPack hp;
		PhaserUpgrade pu;

		Point[] hPoints = new Point[] { new Point(3875, 75)

		};

		Point[] pPoints = new Point[] { new Point(1760, 60) };

		for (int i = 0; i < hPoints.length; i++) {
			hp = new HealthPack(tileMap, gsm);
			hp.setPosition(hPoints[i].x, hPoints[i].y);
			hp.setMovement(false);
			hp.setMultiplier(1.5);
			hp.setType(0); // sending 0 for health effects, 1 for phaser effects
			powerUps.add(hp);

		}

		for (int i = 0; i < pPoints.length; i++) {
			pu = new PhaserUpgrade(tileMap, gsm);
			pu.setPosition(pPoints[i].x, pPoints[i].y);
			pu.setMovement(false);
			pu.setMultiplier(1.5);
			pu.setType(1); // sending 0 for health effects, 1 for phaser effects
			powerUps.add(pu);

		}

	}

	// populating collectables
	private void populateCollectables() {
		collectables = new ArrayList<Collectable>();
		Star s;

		Point[] starPoints = new Point[] {
				// new Point(380, 200),
				// new Point(410, 50),
				new Point(680, 50), new Point(1030, 190), new Point(1580, 60), new Point(2100, 80),
				new Point(2600, 100), new Point(3200, 100), new Point(3800, 50) };

		for (int i = 0; i < starPoints.length; i++) {
			s = new Star(tileMap, gsm);
			s.setPosition(starPoints[i].x, starPoints[i].y);
			s.setMovement(false);
			s.setEffect(0);
			s.setType(0); // 0 for stars....
			collectables.add(s);

		}

	}
	


	public void update() {

		// for timer
		this.elapsed = ( System.nanoTime() - startTimer) / 1000000;
		this.currentScore = gsm.level_2_current_score;

		if(!this.getMute()) {
			// audio update
			mc++;
			if (mc > 375) {
				bgMusic.play();
				mc = 0;
			}
		}

		// check quit
		if (player.getQuit()) {
			bgMusic.stop();
			gsm.setState(4); // (4) levelselectstate (0) main menu
		}

		// update player
		player.update();

		tileMap.setPosition(GamePanel.WIDTH / 2 - player.getx(), GamePanel.HEIGHT / 2 - player.gety());

		// set background
		bg.setPosition(tileMap.getx(), tileMap.gety());

		// attack enemies
		player.checkAttack(enemies, powerUps, collectables);
		if (player.checkDead()) {

			gsm.setState(3);///////////////////////// to do death screen
			bgMusic.stop();
		}

		if (player.getx() >= 5715 && player.getx() <= 5745 && player.gety() > 180) {
			// spokvictorySfx.play();
			if (bossIsDead) {
				
				finalTime = getElapsed();
				gsm.level_2_time = finalTime;
				gsm.level_2_current_score += 1000;
				gsm.forever_score += 1000;
				bgMusic.stop();
				gsm.setState(5);
			}

		}

		// update all enemies
		for (int i = 0; i < enemies.size(); i++) {
			Enemy e = enemies.get(i);
			e.update(gsm);
			if (e.isDead()) {
				gsm.level_2_current_score += e.getScore();
				gsm.forever_score += e.getScore();
				//System.out.println(gsm.forever_score);
				if (e.isBoss()) {
					bossIsDead = true;
				}
				enemies.remove(i);
				i--;
				explosions.add(new Explosion(e.getx(), e.gety()));

			}

		}

		// update all powerUps
		for (int i = 0; i < powerUps.size(); i++) {
			PowerUp ph = powerUps.get(i);
			ph.update(gsm);
			if (ph.isUsed()) {
				puSfx.play();
				gsm.level_2_current_score += ph.getScore();
				gsm.forever_score += ph.getScore();
				powerUps.remove(i);
				i--;
				// could add powerUp animation here for when player gets it... #todo...
				// could alter gamestate here if you wanted....scary thots

			}
		}

		// update all collectables
		for (int i = 0; i < collectables.size(); i++) {
			Collectable c = collectables.get(i);
			c.update(gsm);
			if (c.isUsed()) {
				cSfx.play();
				gsm.level_2_current_score += c.getScore();
				gsm.forever_score += c.getScore();
				if (player.getCollectablesFound() >= maxCollectables) {
					gsm.level_2_current_score += 750;
					gsm.level_2_current_score += c.getScore();
					gsm.forever_score += 750;
					finalTime = getElapsed();
					gsm.level_2_time = finalTime;
					bgMusic.stop();
					gsm.setState(5);
				}

				// play sound that player got it
				collectables.remove(i);
				i--;

			}
		}

		// update all explosions
		for (int i = 0; i < explosions.size(); i++) {
			explosions.get(i).update();
			if (explosions.get(i).shouldRemove()) {
				explosions.remove(i);
				i--;
			}
		}

	}

	public void draw(Graphics2D g) {
		// draw background
		bg.draw(g);

		// draw tileMap
		tileMap.draw(g);

		// draw player
		player.draw(g);

		// draw enemies
		for (int i = 0; i < enemies.size(); i++) {
			enemies.get(i).draw(g);
		}

		// draw power ups
		for (int i = 0; i < powerUps.size(); i++) {
			powerUps.get(i).draw(g);
		}

		for (int i = 0; i < collectables.size(); i++) {
			collectables.get(i).draw(g);
		}

		// draw explosions
		for (int i = 0; i < explosions.size(); i++) {
			explosions.get(i).setMapPosition((int) tileMap.getx(), (int) tileMap.gety());
			explosions.get(i).draw(g);
		}

		// draw HUD
		hud.draw(this, g, 0);
		if (player.getx() >= 5370) {
			bossHud.draw(this, g, 1);
		}
		timerHud.draw(this, g, 2);

	}

	// input
	public void keyPressed(int k) {

		if (k == KeyEvent.VK_LEFT) {
			player.setLeft(true);
		}
		if (k == KeyEvent.VK_RIGHT) {
			player.setRight(true);
		}
		if (k == KeyEvent.VK_UP) {
			player.setUp(true);
		}
		if (k == KeyEvent.VK_DOWN) {
			player.setDown(true);
		}
		if (k == KeyEvent.VK_SPACE) {
			player.setJumping(true);
		}
		if (k == KeyEvent.VK_SHIFT) {
			player.setGliding(true);
		}
		if (k == KeyEvent.VK_S) {
			player.setGripping(true);
		}
		if (k == KeyEvent.VK_F) {
			player.setShooting(true);
		}
		if (k == KeyEvent.VK_P) {
			player.setQuit(true);
		}

	}

	public void keyReleased(int k) {

		if (k == KeyEvent.VK_LEFT) {
			player.setLeft(false);
		}
		if (k == KeyEvent.VK_RIGHT) {
			player.setRight(false);
		}
		if (k == KeyEvent.VK_UP) {
			player.setUp(false);
		}
		if (k == KeyEvent.VK_DOWN) {
			player.setDown(false);
		}
		if (k == KeyEvent.VK_SPACE) {
			player.setJumping(false);
		}
		if (k == KeyEvent.VK_SHIFT) {
			player.setGliding(false);
		}
		if (k == KeyEvent.VK_S) {
			player.setGripping(false);
		}
		if (k == KeyEvent.VK_F) {
			player.setShooting(false);
		}

	}

	

}
