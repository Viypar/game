package GameState;


import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.IOException;

import Audio.AudioPlayer;
//import File.Save;
import TileMap.Background;

public class MenuState extends GameState {

	private Background bg;

	private int currentChoice = 0;
	private String[] options = { "Start", "How to Play", "Controls", "Quit" };
	//private Color titleColor;
	private Font titleFont;
	private Font font;
	private Font iteration;
	
	private AudioPlayer up_sound = new AudioPlayer("/SFX/up_menu_sound.mp3");
	private AudioPlayer down_sound = new AudioPlayer("/SFX/down_menu_sound.mp3");
	private AudioPlayer select_sound = new AudioPlayer("/SFX/select_menu_sound.mp3");
	
	// save stuff
	private Save s;

	public MenuState(GameStateManager gsm) {

		
		this.gsm = gsm;

		try {

			bg = new Background("/Backgrounds/awstitlebackground.gif", 1);
			bg.setVector(-.3, 0); // (-0.1, 0)

			//titleColor = new Color(128, 128, 128);
			titleFont = new Font("Lucida Sans", Font.PLAIN, 24);
			font = new Font("Century Gothic", Font.PLAIN, 12);
			iteration = new Font("Lucida Sans", Font.PLAIN, 10);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void init() {
	}

	public void update() {
		bg.update();
	}

	public void draw(Graphics2D g) {

		// draw bg
		bg.draw(g);

		// draw title
		g.setColor(Color.WHITE);
		g.setFont(titleFont);
		g.drawString("Adventures with Spock", 30, 80);

		// draw menu
		g.setFont(font);
		for (int i = 0; i < options.length; i++) {
			if (i == currentChoice) {
				g.setColor(Color.WHITE);
			} else {
				g.setColor(Color.GRAY);
			}
			g.drawString(options[i], 140, 120 + i * 20);
		}
		g.setColor(Color.WHITE);
		g.setFont(iteration);
		g.drawString("Times Played: " + gsm.times_played, 10, 230);
		g.drawString("All-Time Score: " + gsm.forever_score, 130, 230);
		g.drawString("@Viypar", 270, 230);
	}

	private void select() throws IOException {
		if (currentChoice == 0) {
			// Start // Level Select
			gsm.setState(GameStateManager.LEVELSELECTSTATE); // add level choosing screen
		}
		if (currentChoice == 1) {
			// Help
			gsm.setState(GameStateManager.HOWTOPLAY1STATE);
		}
		if (currentChoice == 2) {
			gsm.setState(GameStateManager.HELPSTATE);
		}
//		if (currentChoice == 3) {
//			mute = true;
//		}
		if (currentChoice == 3) {
			System.exit(0);
		}
	
	}
	
	// mouse 
	public void mouseClicked(int k) throws IOException {
		select();
	}

	public void keyPressed(int k) {
		if (k == KeyEvent.VK_ENTER) {
			select_sound.play();
			try {
				select();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (k == KeyEvent.VK_UP) {
			up_sound.play();
			currentChoice--;
			if (currentChoice == -1) {
				currentChoice = options.length - 1;
			}
		}
		if (k == KeyEvent.VK_DOWN) {
			down_sound.play();
			currentChoice++;
			if (currentChoice == options.length) {
				currentChoice = 0;
			}
		}

	}

	public void keyReleased(int k) {
	}



}
