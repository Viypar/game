package GameState;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;

import TileMap.Background;

public class HowToPlay4State extends GameState {


	private Background bg;

	private int currentChoice = 0;
	private String[] options = { "Back", "Next" };
	//private Color titleColor;
	private Font titleFont;

	private Font font;
	
	public HowToPlay4State(GameStateManager gsm) {
		this.gsm = gsm;
		
		try {

			bg = new Background("/Backgrounds/collectables_menu.gif", 1);
			bg.setVector(0, 0); // (-0.1, 0)

			//titleColor = new Color(128, 128, 128);
			titleFont = new Font("Courier New", Font.PLAIN, 20);
			font = new Font("Courier New", Font.PLAIN, 12);

		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void init() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update() {
		bg.update();
		
	}

	@Override
	public void draw(Graphics2D g) {
		// draw bg
				bg.draw(g);

				// draw title
				g.setColor(Color.WHITE);
				g.setFont(titleFont);
				g.drawString("Collectables", 100, 80);
				g.setFont(font);
				g.drawString("Collect all items for Special rewards", 40, 110);
				g.drawString("Collectables increase speed and health.", 30, 180);
				
				// draw menu
				g.setFont(font);
				for (int i = 0; i < options.length; i++) {
					if (i == currentChoice) {
						g.setColor(Color.WHITE);
					} else {
						g.setColor(Color.GRAY);
					}
					g.drawString(options[i], 120 + i * 60, 220);
				}
		
	}
	
	private void select() {
		if (currentChoice == 0) {
			// Start // Level Select
			gsm.setState(GameStateManager.HOWTOPLAY3STATE); // add level choosing screen
		}
		if (currentChoice == 1) {
			// Help
			gsm.setState(GameStateManager.HOWTOPLAY5STATE);
		}

	}

	@Override
	public void keyPressed(int k) {
		if (k == KeyEvent.VK_ENTER) {
			select_sound.play();
			select();
		}
		if (k == KeyEvent.VK_LEFT) {
			down_sound.play();
			currentChoice--;
			if (currentChoice == -1) {
				currentChoice = options.length - 1;
			}
		}
		if (k == KeyEvent.VK_RIGHT) {
			up_sound.play();
			currentChoice++;
			if (currentChoice == options.length) {
				currentChoice = 0;
			}
		}
		
	}

	@Override
	public void keyReleased(int k) {
		// TODO Auto-generated method stub
		
	}


	
}
