package GameState;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import Audio.AudioPlayer;
import Entity.Collectable;
import Entity.Enemy;
import Entity.Explosion;
import Entity.HUD;
import Entity.HealthPack;
import Entity.PhaserUpgrade;
import Entity.Player;
import Entity.PowerUp;
import Entity.Star;
import Entity.Enemies.Gorn;
import Entity.Enemies.Pancake;
import Entity.Enemies.Vampire;
import Main.GamePanel;
import TileMap.Background;
import TileMap.TileMap;

public class LevelDeathRowState extends GameState {

	private TileMap tileMap;
	private Background bg;

	private Player player;
	private boolean bossIsDead = false;

	private ArrayList<Enemy> enemies;
	private ArrayList<PowerUp> powerUps;
	private ArrayList<Collectable> collectables;
	private ArrayList<Explosion> explosions;

	private HUD hud;
	private HUD bossHud;
	private HUD timerHud;

	private AudioPlayer bgMusic;
	public int mc;
	private AudioPlayer puSfx;
	private AudioPlayer cSfx;

	public LevelDeathRowState(GameStateManager gsm) {
		this.gsm = gsm;
		init();
	}

	@Override
	public void init() {

		// audio mute
		//this.mute = true;
		
		// setting max number of collectables for this level
		this.maxCollectables = 5;

		tileMap = new TileMap(30);
		tileMap.loadTiles("/Tilesets/vulcantiles.gif");
		tileMap.loadMap("/Maps/deathrow.map");
		tileMap.setPosition(0, 0);
		tileMap.setTween(.07); // 0.07

		bg = new Background("/Backgrounds/deathrow_background.gif", 0.15); // todo

		player = new Player(tileMap, gsm);
		player.setPosition(45, 230); // 2300,220

		populateEnemies();
		populatePowerUps();
		populateCollectables();

		explosions = new ArrayList<Explosion>();

		hud = new HUD(player);
		timerHud = new HUD(elapsed);

		bgMusic = this.level_music_danger1;
		puSfx = new AudioPlayer("/SFX/spokvoice_find_2.mp3");
		cSfx = new AudioPlayer("/SFX/collectable_found.mp3");
		
		if(!this.getMute()) {
			bgMusic.play();
			mc = 0;
		}
		
		startTimer = System.nanoTime();
		

	}

	private void populateEnemies() {

		enemies = new ArrayList<Enemy>();

		Pancake p;
		Point[] pPoints = new Point[] { new Point(300, 80), new Point(690, 50), new Point(1000, 80),
				new Point(1500, 170), new Point(2200, 80), new Point(2380, 170), new Point(2500, 80)

		};

		Gorn gorn;
		Point[] gPoints = new Point[] { new Point(540, 220), new Point(780, 220), new Point(1050, 220),
				new Point(1350, 220), new Point(1530, 220), new Point(1950, 220), new Point(2340, 220)

		};

		Vampire v;
		Point[] vPoints = new Point[] { new Point(2700, 230) };

		// pancake spawning
		for (int i = 0; i < pPoints.length; i++) {
			p = new Pancake(tileMap, gsm);
			p.setPosition(pPoints[i].x, pPoints[i].y);
			p.setBoss(false);
			p.setType(0); // sending 0 for horizontal pancakes :)
			enemies.add(p);

		}

		// gorn
		for (int i = 0; i < gPoints.length; i++) {
			gorn = new Gorn(tileMap, gsm, player);
			gorn.setPosition(gPoints[i].x, gPoints[i].y);
			gorn.setBoss(false);
			gorn.setMaxHealth(15);
			if (gorn.isBoss()) {
				bossHud = new HUD(gorn);
			}
			enemies.add(gorn);
		}

		// vampire
		for (int i = 0; i < vPoints.length; i++) {
			v = new Vampire(tileMap, gsm, player);
			v.setPosition(vPoints[i].x, vPoints[i].y);
			v.setBoss(true);
			v.setMaxHealth(40);
			if (v.isBoss()) {
				bossHud = new HUD(v);
			}
			enemies.add(v);
		}

	}

	// populating power ups
	private void populatePowerUps() {
		powerUps = new ArrayList<PowerUp>();
		HealthPack hp;
		PhaserUpgrade pu;

		Point[] hPoints = new Point[] { new Point(2160, 70)

		};

		Point[] pPoints = new Point[] { new Point(150, 260) };

		for (int i = 0; i < hPoints.length; i++) {
			hp = new HealthPack(tileMap, gsm);
			hp.setPosition(hPoints[i].x, hPoints[i].y);
			hp.setMovement(false);
			hp.setMultiplier(3);
			hp.setType(0); // sending 0 for health effects, 1 for phaser effects
			powerUps.add(hp);

		}

		for (int i = 0; i < pPoints.length; i++) {
			pu = new PhaserUpgrade(tileMap, gsm);
			pu.setPosition(pPoints[i].x, pPoints[i].y);
			pu.setMovement(false);
			pu.setMultiplier(2);
			pu.setType(1); // sending 0 for health effects, 1 for phaser effects
			powerUps.add(pu);

		}

	}

	private void populateCollectables() {
		collectables = new ArrayList<Collectable>();
		Star s;

		Point[] starPoints = new Point[] { new Point(780, 180), new Point(1270, 50), new Point(1680, 230),
				new Point(1900, 50), new Point(2600, 230) };

		for (int i = 0; i < starPoints.length; i++) {
			s = new Star(tileMap, gsm);
			s.setPosition(starPoints[i].x, starPoints[i].y);
			s.setMovement(false);
			s.setEffect(0);
			s.setType(0); // 0 for stars....
			collectables.add(s);

		}

	}

	@Override
	public void update() {
		
		this.elapsed = (System.nanoTime() - startTimer) / 1000000;
		this.currentScore = gsm.level_5_current_score;
		
		// audio update
		if(!this.getMute()) {
			mc++;
			if (mc >= 375) {
				bgMusic.play();
				mc = 0;
			}
		}

		// check quit
		if (player.getQuit()) {
			bgMusic.stop();
			gsm.setState(4); // (4) levelselectstate (0) main menu
		}

		// update player
		player.update();

		tileMap.setPosition(GamePanel.WIDTH / 2 - player.getx(), GamePanel.HEIGHT / 2 - player.gety());

		// set background
		bg.setPosition(tileMap.getx(), tileMap.gety());

		// attack enemies
		player.checkAttack(enemies, powerUps, collectables);
		if (player.checkDead()) {

			gsm.setState(3);///////////////////////// to do death screen
			bgMusic.stop();
		}

		if (player.getx() <= 40 && player.gety() > 200) {
			// spokvictorySfx.play();
			if (bossIsDead) {
				finalTime = getElapsed();
				gsm.level_5_time = finalTime;
				gsm.level_5_current_score += 1000;
				gsm.forever_score += 1000;
				bgMusic.stop();
				gsm.setState(5);
			}
		}

		// update all enemies
		for (int i = 0; i < enemies.size(); i++) {
			Enemy e = enemies.get(i);
			e.update(gsm);
			if (e.isDead()) {
				gsm.level_5_current_score += e.getScore();
				gsm.forever_score += e.getScore();
				if (e.isBoss()) {

					bossIsDead = true;
				}

				enemies.remove(i);
				i--;
				explosions.add(new Explosion(e.getx(), e.gety()));

			}

		}

		// update all powerUps
		for (int i = 0; i < powerUps.size(); i++) {
			PowerUp ph = powerUps.get(i);
			ph.update(gsm);
			if (ph.isUsed()) {
				puSfx.play();
				gsm.level_5_current_score += ph.getScore();
				gsm.forever_score += ph.getScore();
				powerUps.remove(i);
				i--;
				// could add powerUp animation here for when player gets it... #todo...
				// could alter gamestate here if you wanted....scary thots

			}
		}

		// update all collectables
		for (int i = 0; i < collectables.size(); i++) {
			Collectable c = collectables.get(i);
			c.update(gsm);
			if (c.isUsed()) {
				cSfx.play();
				gsm.level_5_current_score += c.getScore();
				gsm.forever_score += c.getScore();
				if (player.getCollectablesFound() >= maxCollectables) {
					gsm.level_5_current_score += 750;
					gsm.forever_score += 750;
					finalTime = getElapsed();
					gsm.level_5_time = finalTime;
					bgMusic.stop();
					gsm.setState(5);
				}

				// play sound that player got it
				collectables.remove(i);
				i--;

			}
		}

		// update all explosions
		for (int i = 0; i < explosions.size(); i++) {
			explosions.get(i).update();
			if (explosions.get(i).shouldRemove()) {
				explosions.remove(i);
				i--;
			}
		}

	}

	@Override
	public void draw(Graphics2D g) {
		// draw background
		bg.draw(g);

		// draw tileMap
		tileMap.draw(g);

		// draw player
		player.draw(g);

		// draw enemies
		for (int i = 0; i < enemies.size(); i++) {
			enemies.get(i).draw(g);
		}
//						
		// draw power ups
		for (int i = 0; i < powerUps.size(); i++) {
			powerUps.get(i).draw(g);
		}

		// draw collectables
		for (int i = 0; i < collectables.size(); i++) {
			collectables.get(i).draw(g);
		}

		// draw explosions
		for (int i = 0; i < explosions.size(); i++) {
			explosions.get(i).setMapPosition((int) tileMap.getx(), (int) tileMap.gety());
			explosions.get(i).draw(g);
		}

		// draw HUD
		hud.draw(this, g, 0); // passing 0 for player, 1 for boss, and 2 for timer huds.
		if (player.getx() >= 2580) {
			bossHud.draw(this, g, 1); // sending 1 for boss
		}
		 timerHud.draw(this, g, 2);

	}

	@Override
	public void keyPressed(int k) {
		if (k == KeyEvent.VK_LEFT) {
			player.setLeft(true);
		}
		if (k == KeyEvent.VK_RIGHT) {
			player.setRight(true);
		}
		if (k == KeyEvent.VK_UP) {
			player.setUp(true);
		}
		if (k == KeyEvent.VK_DOWN) {
			player.setDown(true);
		}
		if (k == KeyEvent.VK_SPACE) {
			player.setJumping(true);
		}
		if (k == KeyEvent.VK_SHIFT) {
			player.setGliding(true);
		}
		if (k == KeyEvent.VK_S) {
			player.setGripping(true);
		}
		if (k == KeyEvent.VK_F) {
			player.setShooting(true);
		}
		if (k == KeyEvent.VK_P) {
			player.setQuit(true);
		}

	}

	@Override
	public void keyReleased(int k) {
		if (k == KeyEvent.VK_LEFT) {
			player.setLeft(false);
		}
		if (k == KeyEvent.VK_RIGHT) {
			player.setRight(false);
		}
		if (k == KeyEvent.VK_UP) {
			player.setUp(false);
		}
		if (k == KeyEvent.VK_DOWN) {
			player.setDown(false);
		}
		if (k == KeyEvent.VK_SPACE) {
			player.setJumping(false);
		}
		if (k == KeyEvent.VK_SHIFT) {
			player.setGliding(false);
		}
		if (k == KeyEvent.VK_S) {
			player.setGripping(false);
		}
		if (k == KeyEvent.VK_F) {
			player.setShooting(false);
		}

	}

	

}
